#ifndef I2A_DS18B20_V1_2_H
#define I2A_DS18B20_V1_2_H
// CJP / Arduino Uno temperature reader v1.2
// Do not include the old implementation alongside this file.
#include <Wire.h>
#include <Arduino.h>
#include <math.h>

#define DS18B20_PORT    14
/* Thermometer Connections (At your choice) */ 
#define THERM_PORT PORTC 
#define THERM_DDR DDRC 
#define THERM_PIN PINC 
#define THERM_DQ PC0 
/* Utils */ 
#define THERM_INPUT_MODE() THERM_DDR&=~(1<<THERM_DQ) 
#define THERM_OUTPUT_MODE() THERM_DDR|=(1<<THERM_DQ) 
#define THERM_LOW() THERM_PORT&=~(1<<THERM_DQ) 
#define THERM_HIGH() THERM_PORT|=(1<<THERM_DQ)
//////////////////////////////////////////////////////////////////////////////////
#define THERM_CMD_CONVERTTEMP 0x44 
#define THERM_CMD_RSCRATCHPAD 0xbe 
#define THERM_CMD_WSCRATCHPAD 0x4e 
#define THERM_CMD_CPYSCRATCHPAD 0x48 
#define THERM_CMD_RECEEPROM 0xb8 
#define THERM_CMD_RPWRSUPPLY 0xb4 
#define THERM_CMD_SEARCHROM 0xf0 
#define THERM_CMD_READROM 0x33 
#define THERM_CMD_MATCHROM 0x55 
#define THERM_CMD_SKIPROM 0xcc 
#define THERM_CMD_ALARMSEARCH 0xec
//////////////////////////////////////////////////////////////////////////////////
uint8_t therm_reset()
{ 
 uint8_t i;
 //Pull line low and wait for 480uS 
 THERM_LOW(); 
 THERM_OUTPUT_MODE(); 
 delayMicroseconds(480); 
 //Release line and wait for 60uS 
 THERM_INPUT_MODE(); 
 delayMicroseconds(60); 
 //Store line value and wait until the completion of 480uS period 
 i=(THERM_PIN & (1<<THERM_DQ)); 
 delayMicroseconds(420); 
 // Presence pulse: zero means present.
 return i;
}
//////////////////////////////////////////////////////////
void therm_write_bit(uint8_t bit)
{ 
 //Pull line low for 1uS 
 THERM_LOW(); 
 THERM_OUTPUT_MODE(); 
 delayMicroseconds(1); 
 //If we want to write 1, release the line (if not will keep low) 
 if(bit) THERM_INPUT_MODE(); //Wait for 60uS and release the line 
 delayMicroseconds(60); 
 THERM_INPUT_MODE(); 
 }
//////////////////////////////////////////////////////////
uint8_t therm_read_bit(void)
{ 
 uint8_t bit=0; 
 //Pull line low for 1uS 
 THERM_LOW(); 
 THERM_OUTPUT_MODE(); 
 delayMicroseconds(1); 
 //Release line and wait for 14uS 
 THERM_INPUT_MODE(); 
 delayMicroseconds(14); 
 //Read line value 
 if(THERM_PIN&(1<<THERM_DQ)) bit=1; 
 //Wait for 45uS to end and return read value 
 delayMicroseconds(45); 
 return bit; 
}
//////////////////////////////////////////////////////////
uint8_t therm_read_byte(void)
{ 
 uint8_t i=8, n=0; 
 while(i--){
  //Shift one position right and store read value 
  n>>=1; 
  n|=(therm_read_bit()<<7);
  } 
  return n;
} 
//////////////////////////////////////////////////////////
void therm_write_byte(uint8_t byte)
{ 
 uint8_t i=8; 
 while(i--){ 
 //Write actual bit and shift one position right to make the next bit ready 
 therm_write_bit(byte&1); 
 byte>>=1; 
 } 
}
//////////////////////////////////////////////////////////
#define THERM_DECIMAL_STEPS_12BIT 625 //.0625 
// Direct mode (ADD=2): one externally powered DS18B20 on Uno A0.
// Parasite-powered sensors require a strong pull-up circuit and are not supported.
inline float therm_read_temperature(void)
{
  if (therm_reset()) return NAN;
  therm_write_byte(THERM_CMD_SKIPROM);
  therm_write_byte(THERM_CMD_CONVERTTEMP);
  const uint32_t started = millis();
  while (!therm_read_bit()) {
    if ((uint32_t)(millis() - started) >= 1000UL) return NAN;
  }
  if (therm_reset()) return NAN;
  therm_write_byte(THERM_CMD_SKIPROM);
  therm_write_byte(THERM_CMD_RSCRATCHPAD);
  uint8_t data[9];
  for (uint8_t i = 0; i < 9; ++i) data[i] = therm_read_byte();
  therm_reset();
  uint8_t crc = 0;
  for (uint8_t i = 0; i < 8; ++i) {
    uint8_t b = data[i];
    for (uint8_t j = 0; j < 8; ++j) {
      const uint8_t mix = (crc ^ b) & 1;
      crc >>= 1;
      if (mix) crc ^= 0x8C;
      b >>= 1;
    }
  }
  if (crc != data[8]) return NAN;
  uint16_t bits = (uint16_t)data[0] | ((uint16_t)data[1] << 8);
  switch (data[4] & 0x60) {
    case 0x00: bits &= 0xFFF8; break;
    case 0x20: bits &= 0xFFFC; break;
    case 0x40: bits &= 0xFFFE; break;
  }
  const int32_t raw = (bits & 0x8000) ? (int32_t)bits - 65536L : bits;
  const float value = raw / 16.0f;
  return (value >= -55.0f && value <= 125.0f) ? value : NAN;
}

#ifndef I2A_DS18B20_POLL_MS
#define I2A_DS18B20_POLL_MS 1000UL
#endif

namespace I2A_DS18B20_Detail {
struct State {
  uint32_t lastAttempt;
  uint32_t lastSuccess;
  float value;
  bool attempted;
  bool lastReadOK;
};
inline State *states() {
  static State s[4] = {
    {0, 0, NAN, false, false}, {0, 0, NAN, false, false},
    {0, 0, NAN, false, false}, {0, 0, NAN, false, false}
  };
  return s;
}
inline void begin() {
  static bool initialized = false;
  if (initialized) return;
  Wire.begin();
#if defined(WIRE_HAS_TIMEOUT)
  // Supported by recent official Arduino AVR Wire cores; microseconds.
  Wire.setWireTimeout(25000UL, true);
#endif
  initialized = true;
}
}

// Compatible public function name, including the original spelling.
// ADD 0: address 10, 2 bytes; ADD 1: address 60, 3 bytes;
// ADD 2: direct sensor on Uno A0; ADD 3: address 97, 7 bytes.
// ADD 4 is intentionally unsupported: the original has no decoder for it.
// I2C decoding preserves the legacy unsigned base-255 convention.
// A successful I2C transfer does NOT prove that the remote sensor is healthy.
inline float GET_TEMPERTURE_SENSOR_VALUE(uint8_t ADD)
{
  if (ADD > 3) return NAN;
  using namespace I2A_DS18B20_Detail;
  State &s = states()[ADD];
  if (ADD != 2) begin();
  const uint32_t now = millis();
  if (s.attempted && (uint32_t)(now - s.lastAttempt) < I2A_DS18B20_POLL_MS)
    return s.value;
  s.attempted = true;
  s.lastAttempt = now;
  s.lastReadOK = false;
  float value = NAN;
  if (ADD == 2) {
    value = therm_read_temperature();
  } else {
    const uint8_t address = (ADD == 0) ? 10 : ((ADD == 1) ? 60 : 97);
    const uint8_t count = (ADD == 0) ? 2 : ((ADD == 1) ? 3 : 7);
#if defined(WIRE_HAS_TIMEOUT)
    Wire.clearWireTimeoutFlag();
#endif
    const uint8_t received = Wire.requestFrom(address, count);
    bool failed = (received != count || Wire.available() != count);
#if defined(WIRE_HAS_TIMEOUT)
    failed = failed || Wire.getWireTimeoutFlag();
#endif
    if (!failed) {
      uint8_t data[7];
      for (uint8_t i = 0; i < count; ++i) {
        const int b = Wire.read();
        if (b < 0) { failed = true; break; }
        data[i] = (uint8_t)b;
      }
      if (!failed) {
        const uint8_t lo = (ADD == 0) ? data[0] : ((ADD == 1) ? data[1] : data[6]);
        const uint8_t hi = (ADD == 0) ? data[1] : ((ADD == 1) ? data[2] : data[5]);
        value = (lo + hi * 255.0f) / 10.0f;
      }
    }
    while (Wire.available() > 0) Wire.read();
  }
  if (!isnan(value)) {
    s.value = value;
    s.lastSuccess = millis();
    s.lastReadOK = true;
  }
  return s.value;
}

// Optional diagnostics. These do not trigger a new measurement.
inline bool I2A_DS18B20_LAST_READ_OK(uint8_t ADD) {
  return ADD <= 3 && I2A_DS18B20_Detail::states()[ADD].lastReadOK;
}
inline uint32_t I2A_DS18B20_LAST_SUCCESS_MS(uint8_t ADD) {
  return ADD <= 3 ? I2A_DS18B20_Detail::states()[ADD].lastSuccess : 0;
}
#endif // I2A_DS18B20_V1_2_H
