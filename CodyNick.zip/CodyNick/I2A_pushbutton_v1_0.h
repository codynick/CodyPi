#ifndef I2A_pushbutton_v1_0
#define I2A_pushbutton_v1_0
#include <Wire.h>
#include <avr/wdt.h>
int8_t GLOBAL_TAG_SW_=0;
///////////////////////////////////////////////////////////
void  PUSH_BUTTON_INITIAL(int8_t add){
	if(add==0){
		pinMode(2,INPUT_PULLUP);
	}
	else {
		Wire.begin();
	}		
		
}
///////////////////////////////////////////////////////////
int8_t READ_PUSH_BUTTON_VALUE(int8_t add){
 uint64_t PUSH_BUTTON_timer=0;
 int8_t  byte1,byte2;
 int16_t RET_VALUE;
 if(add==0){
	 if(digitalRead(2) == 0)return 1;
	 else return 0;
 }	 
 else if(add==1)	
 {
  if (millis() - PUSH_BUTTON_timer > 100) {
  wdt_enable(WDTO_2S);
  PUSH_BUTTON_timer= millis();
  Wire.requestFrom(92,2);
  while (Wire.available()) 
  {
   byte1= Wire.read();
   byte2= Wire.read();
   
  }wdt_disable();}
  if(byte2==0)return 1;
  else return 0;
 }
 else if(add==2)	
 {
  if (millis() - PUSH_BUTTON_timer > 100) {
  wdt_enable(WDTO_2S);
  PUSH_BUTTON_timer= millis();
  Wire.requestFrom(102,2);
  while (Wire.available()) 
  {
   RET_VALUE= Wire.read();
   RET_VALUE=RET_VALUE<<8;
   RET_VALUE|= Wire.read();
   
  }wdt_disable();}
   if(RET_VALUE&0x01)return 1;
   else return 0;
 }
	
 
 return 0;	
}
///////////////////////////////////////////////////////////
int8_t READ_KEY_BUTTON_SWITCHMASTER(int8_t add){
 uint64_t PUSH_BUTTON_timer=0;
 int8_t  byte1,byte2;
 int16_t RET_VALUE=0;
 if (millis() - PUSH_BUTTON_timer > 100) {
  wdt_enable(WDTO_2S);
  PUSH_BUTTON_timer= millis();
  Wire.requestFrom(102,2);
  while (Wire.available()) 
  {
   RET_VALUE= Wire.read();
   RET_VALUE=RET_VALUE<<8;
   RET_VALUE|= Wire.read();
   
  }wdt_disable();}
   if(RET_VALUE&0x02)return 1;
   else return 0;
}
#endif