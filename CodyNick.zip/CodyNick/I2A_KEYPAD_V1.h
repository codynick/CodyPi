#ifndef I2A_KEYPAD_V1_H
#define I2A_KEYPAD_V1_H
#include <Wire.h>
#include <avr/wdt.h>
float LAST_KEY_____=-1;
uint64_t T_out_keypad_timer;
/////////////////////////////////////////////////
float get_last_key_pressed(uint8_t e)
{
  float RET=0;	
  uint8_t KEY;

  
  	uint64_t keypad_timer;
if (millis() - keypad_timer > 100) {
  wdt_enable(WDTO_2S);
   keypad_timer = millis();
   Wire.requestFrom(100, 2);
  while (Wire.available()) {
   uint8_t i2cdata[2];
   Wire.readBytes(i2cdata,2);
   KEY = i2cdata[1];
   }wdt_disable();}
  
  //KEY=keypad_num;
  if     (KEY==48)RET=0; 
  else if(KEY==49)RET=1; 
  else if(KEY==50)RET=2; 
  else if(KEY==51)RET=3; 
  else if(KEY==52)RET=4;
  else if(KEY==53)RET=5;
  else if(KEY==54)RET=6;
  else if(KEY==55)RET=7;
  else if(KEY==56)RET=8;
  else if(KEY==57)RET=9;
  else if(KEY==42)RET=10;
  else if(KEY==35)RET=11;
  else RET= -1;
  if((millis()-T_out_keypad_timer)>200)LAST_KEY_____= -1;
  
 if(RET!=-1){
	 LAST_KEY_____=RET;
	 T_out_keypad_timer=millis();
 }

 //key_value=keypad_num;
 //keypad_num=0;
 delay(5);
 return LAST_KEY_____; 
}
#endif