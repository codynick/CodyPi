#ifndef I2A_Switchmaster_V1
#define I2A_Switchmaster_V1
#include <Wire.h>
#include <avr/wdt.h>
float GET_SwtichMaster_VALEU_(char add)
{
   uint64_t ADC_TIMER=0;
   int recive=0;
   uint8_t ret;
   float f=0;
    //LOADCELL_ADC_VALUE_I2A=233;
   if (millis() - ADC_TIMER > 2000) {
   wdt_enable(WDTO_2S);
   ADC_TIMER= millis();
   Wire.requestFrom(102, 2);
   while (Wire.available()) {
   uint8_t i2cdata[4];
   Wire.readBytes(i2cdata,2);
   
   recive=i2cdata[0];
   recive=recive<<8;
   recive+=i2cdata[1];
   
 }wdt_disable();
}
//recive=~recive;
recive=recive>>2;
ret=recive;
ret=~ret;
f=ret;
return f;	
}
///////////////////////////////////////////////////////////
#endif