#ifndef I2A_internet_IOT_______V1
#define I2A_internet_IOT_______V1
#include <Arduino.h>
#include <Wire.h>
#include <SoftwareSerial.h>
#include <Wire.h>
#include <avr/wdt.h>
union Converting_datatype {
   long L;
   float F;
   char B[4];
} convert_;  
////////////////////////////////////////////////////////////////
void IOT_INIT___________(void){
 Wire.begin();
}
////////////////////////////////////////////////////////////////
void Set_IOT_Text_(char *str_button,int button_number){
}
////////////////////////////////////////////////////////////////
void Set_IOT_Lable_(char *str_button,int button_number){	
  char i2cdata[30],i;
  i2cdata[0]=0xA1;
  i2cdata[1]=button_number;
  strcpy(i2cdata+2, str_button);
  Wire.beginTransmission(117);
  Wire.write(i2cdata,20);
  Wire.endTransmission();
}
////////////////////////////////////////////////////////////////
void Set_IOT_3value_(float f1,float f2,float f3){
  char i2cdata[30],i;
  i2cdata[0]=0xF1;
  convert_.F=f1;
  
  
  i2cdata[1]=convert_.B[0];
  i2cdata[2]=convert_.B[1];
  i2cdata[3]=convert_.B[2];
  i2cdata[4]=convert_.B[3];
  convert_.F=f2;
  i2cdata[5]=convert_.B[0];
  i2cdata[6]=convert_.B[1];
  i2cdata[7]=convert_.B[2];
  i2cdata[8]=convert_.B[3];
  convert_.F=f3;
  i2cdata[9]=convert_.B [0];
  i2cdata[10]=convert_.B[1];
  i2cdata[11]=convert_.B[2];
  i2cdata[12]=convert_.B[3];
  Wire.beginTransmission(117);
  Wire.write(i2cdata,20);
  Wire.endTransmission();


}
////////////////////////////////////////////////////////////////
void Set_IOT_6value_(float f1,float f2,float f3,float f4,float f5,float f6){
  char i2cdata[30],i;
  i2cdata[0]=0xF1;
  convert_.F=f1;

  i2cdata[1]=convert_.B[0];
  i2cdata[2]=convert_.B[1];
  i2cdata[3]=convert_.B[2];
  i2cdata[4]=convert_.B[3];
  convert_.F=f2;
  i2cdata[5]=convert_.B[0];
  i2cdata[6]=convert_.B[1];
  i2cdata[7]=convert_.B[2];
  i2cdata[8]=convert_.B[3];
  convert_.F=f3;
  i2cdata[9]=convert_.B [0];
  i2cdata[10]=convert_.B[1];
  i2cdata[11]=convert_.B[2];
  i2cdata[12]=convert_.B[3];
  convert_.F=f4;
  i2cdata[13]=convert_.B[0];
  i2cdata[14]=convert_.B[1];
  i2cdata[15]=convert_.B[2];
  i2cdata[16]=convert_.B[3];
  convert_.F=f5;
  i2cdata[17]=convert_.B[0];
  i2cdata[18]=convert_.B[1];
  i2cdata[19]=convert_.B[2];
  i2cdata[20]=convert_.B[3];
  convert_.F=f6;
  i2cdata[21]=convert_.B[0];
  i2cdata[22]=convert_.B[1];
  i2cdata[23]=convert_.B[2];
  i2cdata[24]=convert_.B[3];
    
  Wire.beginTransmission(117);
  Wire.write(i2cdata,25);
  Wire.endTransmission();


}
////////////////////////////////////////////////////////////////
void Set_IOT_value_tag(float f1,char *str){
  char i2cdata[30],i;
  i2cdata[0]=0xF1;
  convert_.F=f1;

  i2cdata[1]=convert_.B[0];
  i2cdata[2]=convert_.B[1];
  i2cdata[3]=convert_.B[2];
  i2cdata[4]=convert_.B[3];
  strcpy(i2cdata+5, str);  
  Wire.beginTransmission(117);
  Wire.write(i2cdata,25);
  Wire.endTransmission();
}
////////////////////////////////////////////////////////////////
float Get_IOT_value_tag(char *str){
  char i2cdata[30],i,counter;
  float ret_value;
  long recive;
  uint64_t www_iot_timer=0;
  i2cdata[0]=0xF2;
  strcpy(i2cdata+1, str);  
  Wire.beginTransmission(117);
  Wire.write(i2cdata,25);
  Wire.endTransmission();
  
  delay(100);
  
  
  if (millis() - www_iot_timer > 2000) {
  wdt_enable(WDTO_2S);
  www_iot_timer = millis();
  Wire.requestFrom(117, 8);
  i=0;
  delay(10);
  counter=0;
  while (Wire.available()) {
	delay(10);
   i2cdata[counter]=Wire.read();
   counter++;

  }wdt_disable();}
  
  
  convert_.B[0]=i2cdata[1];
  convert_.B[1]=i2cdata[2];
  convert_.B[2]=i2cdata[3];
  convert_.B[3]=i2cdata[4];
   
    ret_value = convert_.L;
	ret_value=ret_value/100;
  
  return ret_value;
}
////////////////////////////////////////////////////////////////

char *Get_IOT_Value(int button_number){
}
////////////////////////////////////////////////////////////////
void Set_IOT_SSID____(char *str_button,int button_number){
  char i2cdata[30],i;
  i2cdata[0]=0x91;
  i2cdata[1]=button_number;
  strcpy(i2cdata+2, str_button);
  Wire.beginTransmission(117);
  Wire.write(i2cdata,20);
  Wire.endTransmission();
}
////////////////////////////////////////////////////////////////
void Set_IOT_PASSWORD____(char *str_button,int button_number){
  char i2cdata[30],i;
  i2cdata[0]=0x92;
  i2cdata[1]=button_number;
  strcpy(i2cdata+2, str_button);
  Wire.beginTransmission(117);
  Wire.write(i2cdata,20);
  Wire.endTransmission();
}
////////////////////////////////////////////////////////////////
void Set_IOT_IDKEY____(char *str_button,int button_number){
  char i2cdata[30],i;
  i2cdata[0]=0x93;
  i2cdata[1]=button_number;
  strcpy(i2cdata+2, str_button);
  Wire.beginTransmission(117);
  Wire.write(i2cdata,30);
  Wire.endTransmission();
}
////////////////////////////////////////////////////////////////
char * Get_IOT_STATUS_(int button_number){
 return 0;
}
#endif