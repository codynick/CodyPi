#ifndef I2A_Trimbar_V1
#define I2A_Trimbar_V1
#include <Wire.h>
#include <avr/wdt.h>
float GET_TRIMBAR_ADC_VALEU_(char add)
{
   uint64_t ADC_TIMER=0;
   int recive=0;
   float f=0;
    //LOADCELL_ADC_VALUE_I2A=233;
   if (millis() - ADC_TIMER > 2000) {
   wdt_enable(WDTO_2S);
   ADC_TIMER= millis();
   Wire.requestFrom(101, 2);
   while (Wire.available()) {
   uint8_t i2cdata[4];
   Wire.readBytes(i2cdata,2);
   
   recive=i2cdata[0];
   recive=recive<<8;
   recive+=i2cdata[1];
 }wdt_disable();
}
f=recive;
return f;	
}
///////////////////////////////////////////////////////////
void SET_THE_TRIMBAR_BAR(float f_value,uint8_t add)
{
   uint16_t value;
   uint8_t shift;
   if(f_value>10)f_value=10;
   if(f_value<0)f_value=0;
   shift=f_value;
   shift=10-shift;
   value=1023;
   value=value>>shift;
   char tb[3];
   tb[0]=value>>8;
   tb[1]=value;
   tb[2]=0xBA;
   Wire.beginTransmission(101);
   Wire.write(tb,3);
   Wire.endTransmission();
}
#endif