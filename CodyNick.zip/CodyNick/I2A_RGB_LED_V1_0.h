#ifndef I2A_RGB_LED_V1_0
#define I2A_RGB_LED_V1_0
#define LED_RED_PORT    5
#define LED_GREEN_PORT  3
#define LED_BLUE_PORT   6
//////////////////////////////////////////
//////////////////////////////////////////
void LED_RGB_init(unsigned char E)
{
	if((E==0)|(E==2)|(E==4))
	 Wire.begin();
  	if(E==1|E==3)
	{
		pinMode(LED_RED_PORT, OUTPUT);
		pinMode(LED_GREEN_PORT, OUTPUT);
		pinMode(LED_BLUE_PORT, OUTPUT);
		
	}
}
//////////////////////////////////////////
void SET_GRB_LED_(unsigned char E,unsigned char RED,unsigned char GREEN,unsigned char BLUE)
{
 if(E==1)
 {
  analogWrite(LED_RED_PORT, RED);
  analogWrite(LED_GREEN_PORT, GREEN);
  analogWrite(LED_BLUE_PORT, BLUE);
 }
 if(E==2)
 {
   char tb[6];
   tb[0]=2;
   tb[1]=0;
   tb[2]=RED;
   tb[3]=GREEN;
   tb[4]=BLUE;
   
   Wire.beginTransmission(92);
   Wire.write(tb,5);
   Wire.endTransmission();
 }
  if(E==3)
 {
  analogWrite(LED_RED_PORT, RED);
  analogWrite(LED_GREEN_PORT, GREEN);
  analogWrite(LED_BLUE_PORT, BLUE);
 }
 if(E==4)
 {
   char tb[6];
   tb[0]=BLUE;
   tb[1]=RED;
   tb[2]=GREEN;
   tb[3]=0xBA;

   
   Wire.beginTransmission(102);
   Wire.write(tb,4);
   Wire.endTransmission();
 }
}
//////////////////////////////////////////
//////////////////////////////////////////
//////////////////////////////////////////
//////////////////////////////////////////
//////////////////////////////////////////
#endif