#ifndef I2A_RGB_MAT_V1_0 
#define I2A_RGB_MAT_V1_0 
#include <Adafruit_NeoPixel.h>
Adafruit_NeoPixel RGBLED(16, A2, NEO_GRB + NEO_KHZ800);
Adafruit_NeoPixel RGBLED_Pro(16, A1, NEO_GRB + NEO_KHZ800);
const unsigned char color_led[8][3] = {{127, 0, 0}, {0, 127, 0}, {0, 0, 127}, {242, 64, 180}, {127, 0, 127}, {0, 127, 127}, {127, 64, 13}, {127, 88, 5}};
const char LED_XY_To_Addr[2][4][4] = {{{15,8,7,0}, {14,9,6,1}, {13,10,5,2} ,{12,11,4,3}},{{15,14,13,12}, {8,9,10,11}, {7,6,5,4} ,{0,1,2,3}}};
const char LED_TO_ADDR[2][16] = {{15,8,7,0,1,6,9,14,13,10,5,2,3,4,11,12}, {15,14,13,12,11,10,9,8,7,6,5,4,3,2,1,0}};
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void RGB_LED_MAT_INIT(char e){
  if(e==0)
  {
   RGBLED.begin();
   pinMode(11,INPUT_PULLUP);
   pinMode(12,INPUT_PULLUP);
  }
  else if(e==1)
  {
   RGBLED_Pro.begin();
   pinMode(4,INPUT_PULLUP);
  }
  else if(e==2)
  {
   Serial.begin(115200);
  }
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void SET_RGB_Mat_X_(char e,uint8_t X,uint8_t R,uint8_t G,uint8_t B){
  if(e==0){if(digitalRead(12)==0){ RGBLED.setPixelColor((int)X , RGBLED.Color((int)R,(int) G,(int) B));
   RGBLED.show();}
  else if(( (int)X >=0)&( (int)X < 0x10))
  { RGBLED.setPixelColor(LED_TO_ADDR[digitalRead(11)][(int)X] , RGBLED.Color((int)R,(int) G,(int) B));
   RGBLED.show();}
  }else if(e==1)
  {
   if(( (int)X >= 0)&( (int)X < 0x10))
  { RGBLED_Pro.setPixelColor(LED_TO_ADDR[digitalRead(4)][(int)X] , RGBLED_Pro.Color((int)R,(int) G,(int) B));
    RGBLED_Pro.show();}
  }
  else if(e==2){//Send To simulator
  }
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void SET_RGB_Mat_X_CC(char e,uint8_t X,uint8_t Color_CODE){
  if(e==0){if(digitalRead(12)==0){ RGBLED.setPixelColor((int)X ,  RGBLED.Color(color_led[(int)Color_CODE][0],color_led[(int)Color_CODE][1], color_led[(int)Color_CODE][2]));
  RGBLED.show();}
  else if(( (int)X >= 0)&( (int)X < 0x10))
  { RGBLED.setPixelColor(LED_TO_ADDR[digitalRead(11)][(int)X] ,  RGBLED.Color(color_led[(int)Color_CODE][0],color_led[(int)Color_CODE][1], color_led[(int)Color_CODE][2]));
  RGBLED.show();}
  }else if(e==1)
  {
   if(( (int)X >= 0)&( (int)X < 0x10))
  { RGBLED_Pro.setPixelColor(LED_TO_ADDR[digitalRead(4)][(int)X] ,  RGBLED_Pro.Color(color_led[(int)Color_CODE][0],color_led[(int)Color_CODE][1], color_led[(int)Color_CODE][2]));
    RGBLED_Pro.show();}
  }
  else if(e==2){//Send To simulator
  }
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void SET_RGB_Mat_X_CC_24bit(char e,uint8_t X,uint32_t Color_CODE){
  if(e==0){if(digitalRead(12)==0){ RGBLED.setPixelColor((int)X ,  Color_CODE);
  RGBLED.show();}
  else if(( (int)X >= 0)&( (int)X < 0x10))
  { RGBLED.setPixelColor(LED_TO_ADDR[digitalRead(11)][(int)X] ,  Color_CODE);
  RGBLED.show();}
  }else if(e==1)
  {
   if(( (int)X >= 0)&( (int)X < 0x10))
  { RGBLED_Pro.setPixelColor(LED_TO_ADDR[digitalRead(4)][(int)X] , Color_CODE);
    RGBLED_Pro.show();}
  }
  else if(e==2){//Send To simulator
  }
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void SET_RGB_Mat_XY(char e,uint8_t X,uint8_t Y,uint8_t R,uint8_t G,uint8_t B){
  if(e==0)
  {
  if(((X>=0)&(X< 4)) & ((Y>=0)&(Y< 4))){RGBLED.setPixelColor(LED_XY_To_Addr[digitalRead(11)][(int)Y][(int)X] , RGBLED.Color((int)R,(int) G,(int) B));
  RGBLED.show();}
  }
  else if(e==1)
  {
  if((Y>=0) &(Y< 4) & (X>=0)& (X< 4)){RGBLED_Pro.setPixelColor(LED_XY_To_Addr[!digitalRead(4)][(int)X][(int)Y] , RGBLED_Pro.Color((int)R,(int) G,(int) B));
  RGBLED_Pro.show();}
  }
  else if(e==2){//Send To simulator
  }  
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void SET_RGB_Mat_XY_CC(char e,uint8_t X,uint8_t Y,uint8_t Color_CODE){
 
  if(e==0)
  {
  if((X>= 0)&(X< 4) & (Y>=0)& (Y< 4)){RGBLED.setPixelColor(LED_XY_To_Addr[digitalRead(11)][(int)Y][(int)X] , RGBLED.Color(color_led[(int)Color_CODE][0],color_led[(int)Color_CODE][1], color_led[(int)Color_CODE][2]));
  RGBLED.show();}
  }
  else if(e==1)
  {
  if((X>=0) & (X< 4) & (Y>=0)& (Y< 4)){RGBLED_Pro.setPixelColor(LED_XY_To_Addr[!digitalRead(4)][(int)X][(int)Y] , RGBLED_Pro.Color(color_led[(int)Color_CODE][0],color_led[(int)Color_CODE][1], color_led[(int)Color_CODE][2]));
  RGBLED_Pro.show();}
  }
  else if(e==2){//Send To simulator
  }  
  
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void SET_RGB_Mat_XY_CC_24bit(char e,uint8_t X,uint8_t Y,uint32_t Color_CODE){
 
  if(e==0)
  {
  if((X>= 0)&(X< 4) & (Y>=0)& (Y< 4)){RGBLED.setPixelColor(LED_XY_To_Addr[digitalRead(11)][(int)Y][(int)X] , Color_CODE);
  RGBLED.show();}
  }
  else if(e==1)
  {
  if((X>=0) & (X< 4) & (Y>=0)& (Y< 4)){RGBLED_Pro.setPixelColor(LED_XY_To_Addr[!digitalRead(4)][(int)X][(int)Y] , Color_CODE);
  RGBLED_Pro.show();}
  }
  else if(e==2){//Send To simulator
  }  
  
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void Clear_All_RGB_Mat(char e){
  if(e==0)
  {RGBLED.clear();
  RGBLED.show();
  }
  else if(e==1)
  {RGBLED_Pro.clear();
  RGBLED_Pro.show();
  }
  else if(e==2){//Send To simulator
  }  
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


#endif
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


