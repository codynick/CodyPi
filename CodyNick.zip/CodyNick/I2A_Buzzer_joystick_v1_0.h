#define I2A_Buzzer_joystick_v1_0
//char joy_mat_i2c_add[2]={8,70};
#define DIRX 1
#define DIRXP 2
#define SPEEDX  4


#define DIRY 8
#define DIRYP 16
#define SPEEDY  32



#define CLICK  64
uint8_t direction[6] = {0,0,0,0,0,0};
uint64_t joystick_timer[5] = {0,0,0,0,0};
uint8_t DIRECTION;

#define VRX_PIN  A3
#define VRY_PIN  A2
#define SW_PIN   11
int VRX, VRY;
void joystick_initial(int8_t add)
{
	if(add==2)
	{
	 //digitalWrite(SW_PIN,1);
	 pinMode(SW_PIN,INPUT_PULLUP);
	 pinMode(VRX_PIN,INPUT);
	 pinMode(VRY_PIN,INPUT);	 
	}
	if(add==3)
	{
	 //digitalWrite(SW_PIN,1);
	 pinMode(SW_PIN,INPUT_PULLUP);
	 pinMode(VRX_PIN,INPUT);
	 pinMode(VRY_PIN,INPUT);	 
	}
	if(add==5)
	{
	 //digitalWrite(SW_PIN,1);
	 pinMode(SW_PIN,INPUT_PULLUP);
	 pinMode(VRX_PIN,INPUT);
	 pinMode(VRY_PIN,INPUT);	 
	}
}
///////////////////////////////////////////////////////////
void loop_loystick(void)
{
  	
  DIRECTION = 0;
  VRY= analogRead(VRX_PIN);
  VRX = analogRead(VRY_PIN);
 

  if( (VRX < 500) && (VRX > 100))
  DIRECTION |= DIRX;
  else if(VRX < 100)
  DIRECTION |= DIRX | SPEEDX;
  else if((VRX > 600) && (VRX < 1000) )
  DIRECTION |= DIRX | DIRXP;
  else if(VRX > 1000)
  DIRECTION |= DIRX | SPEEDX | DIRXP;
  // if( (VRY < 500) && (VRY > 100))
  // DIRECTION |= DIRY;
  // else if(VRY < 100)
  // DIRECTION |= DIRY | SPEEDY;
  // else if((VRY > 600) && (VRY < 1000) )
  // DIRECTION |= DIRY | DIRYP;
  // else if(VRY > 1000)
  // DIRECTION |= DIRY | SPEEDY | DIRYP;

  if( (VRY < 500) && (VRY > 100))
  DIRECTION |= DIRY | DIRYP;
  else if(VRY < 100)
  DIRECTION |= DIRY | SPEEDY | DIRYP;
  else if((VRY > 600) && (VRY < 1000) )
  DIRECTION |= DIRY;
  else if(VRY > 1000)
  DIRECTION |= DIRY | SPEEDY;


  
  if(digitalRead(SW_PIN) == 0)
  DIRECTION |= CLICK;


}
///////////////////////////////////////////////////////////
void Read_joystick_value(int8_t add)
{
	uint8_t DIRECTION_B;
	uint8_t DIRECTION_BB;
	int VRX, VRY;
	unsigned char Buff[10];
 if((add==0))	
 {
  if (millis() - joystick_timer[add] > 100) {
  wdt_enable(WDTO_2S);
  joystick_timer[add] = millis();
  Wire.requestFrom(8, 1);
  while (Wire.available()) {direction[add]= Wire.read();
  }wdt_disable();}
 }
 else if(add==1)	
 {
  if (millis() - joystick_timer[add] > 100) {
  wdt_enable(WDTO_2S);
  joystick_timer[add] = millis();
  Wire.requestFrom(70, 1);
  while (Wire.available()) {DIRECTION_B= Wire.read();
  }wdt_disable();}
  
  DIRECTION_BB=0;
  //if(DIRECTION_B&CLICK)
  if     ((DIRECTION_B & (DIRX | DIRXP | SPEEDX)) == (DIRX | SPEEDX))    DIRECTION_BB|= (DIRY | SPEEDY | DIRYP);  //UP->left
  if((DIRECTION_B & (DIRY | DIRYP | SPEEDY)) == (DIRY | SPEEDY))         DIRECTION_BB|= (DIRX | SPEEDX);          //rigth->up
  if((DIRECTION_B & (DIRY | DIRYP | SPEEDY)) == (DIRY | SPEEDY | DIRYP)) DIRECTION_BB|= (DIRX | SPEEDX | DIRXP);  //left->down
  if((DIRECTION_B & (DIRX | DIRXP | SPEEDX)) == (DIRX | SPEEDX | DIRXP)) DIRECTION_BB|= (DIRY | SPEEDY);          //down->rigth
  if     (CLICK&DIRECTION_B)                                                  DIRECTION_BB|=CLICK;
  
 DIRECTION_B=DIRECTION_BB;
  
  direction[add]=DIRECTION_B;
 }
 else if(add==2)
 {
	loop_loystick();
    direction[2]=DIRECTION; 	
 }	 
 else if(add==3)
 {
	loop_loystick();
    direction[3]=DIRECTION; 	
 }
 else if(add==5)
 {
	loop_loystick();
    direction[5]=DIRECTION; 	
 }	 
 if((add==4))	
 {
  if (millis() - joystick_timer[add] > 500) {
  wdt_enable(WDTO_2S);
  joystick_timer[add] = millis();
  Wire.requestFrom(97, 7);
  while (Wire.available()) 
  {
   Buff[0]= Wire.read();
   Buff[1]= Wire.read();
   Buff[2]= Wire.read();
   Buff[3]= Wire.read();
   Buff[4]= Wire.read();
   Wire.read();
   Wire.read();
   VRY=Buff[1];
   VRY=VRY<<8;
   VRY+=Buff[2];
   
   VRX=Buff[3];
   VRX=VRX<<8;
   VRX+=Buff[4];
  DIRECTION=0; 
  if( (VRX < 400) && (VRX > 100))
  DIRECTION |= DIRX;
  else if(VRX < 100)
  DIRECTION |= DIRX | SPEEDX;
  else if((VRX > 600) && (VRX < 1000) )
  DIRECTION |= DIRX | DIRXP;
  else if(VRX > 1000)
  DIRECTION |= DIRX | SPEEDX | DIRXP;
  // if( (VRY < 500) && (VRY > 100))
  // DIRECTION |= DIRY;
  // else if(VRY < 100)
  // DIRECTION |= DIRY | SPEEDY;
  // else if((VRY > 600) && (VRY < 1000) )
  // DIRECTION |= DIRY | DIRYP;
  // else if(VRY > 1000)
  // DIRECTION |= DIRY | SPEEDY | DIRYP;

  if( (VRY < 400) && (VRY > 100))
  DIRECTION |= DIRY | DIRYP;
  else if(VRY < 100)
  DIRECTION |= DIRY | SPEEDY | DIRYP;
  else if((VRY > 600) && (VRY < 1000) )
  DIRECTION |= DIRY;
  else if(VRY > 1000)
  DIRECTION |= DIRY | SPEEDY;


  
  if(Buff[0] == 0)
  DIRECTION |= CLICK;

  
   
  }wdt_disable();}
  direction[4]=DIRECTION; 
  //delay(10);
 }	
	
}