char joy_mat_i2c_add[2]={8,70};
#define DIRX 1
#define DIRXP 2
#define SPEEDX  4
#define DIRY 8
#define DIRYP 16
#define SPEEDY  32
#define CLICK  64
uint8_t direction[2] = {0,0};
uint64_t joystick_timer[3] = {0,0,0};
void Read_joystick_value(int8_t add)
{
 if((add==0)|(add==1))	
 {
  if (millis() - joystick_timer[add] > 100) {
  wdt_enable(WDTO_2S);
  joystick_timer[add] = millis();
  Wire.requestFrom(joy_mat_i2c_add[add], 1);
  while (Wire.available()) {direction[add]= Wire.read();
  }wdt_disable();}
 }
 else if(add==2)
 {
	 
 }	 
	
	
	
}