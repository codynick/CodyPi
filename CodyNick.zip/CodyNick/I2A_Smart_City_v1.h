#ifndef I2A_Smart_City_v1
#include <Arduino.h>
#include <Wire.h>
#include <avr/wdt.h>
#define I2A_Smart_City_v1 
union DATA_CONVERTER 
{ 
    long L; 
    float FP; 
    char BI[4]; 
}; 
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void SMART_CITY_OBJECTS_init(char e)
{
 Wire.begin();
}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void set_SC_buzzer_digital(char add,char state)
{
	//if(add==0)
    if(state>1)state=1;
	{
     char tb[6];
     tb[0]=1;
     tb[1]=state;
     tb[2]=0;
     tb[3]=0;
     tb[4]=0;
     if     (add==0)Wire.beginTransmission(111);
	 else if(add==1)Wire.beginTransmission(112);
     Wire.write(tb,5);
     Wire.endTransmission();
	}
	delay(1);
}
//////////////////////////////////////////
void SET_RGB_LED_Smart_City(unsigned char E,unsigned char RED,unsigned char GREEN,unsigned char BLUE)
{
	char tb[6];
	if(RED>=255)RED=254;
	if(GREEN>=255)GREEN=254;
	if(BLUE>=255)BLUE=254;
	if((E==0)|(E==2)|(E==4)|(E==5))
	{
     tb[0]=2;
     tb[1]=0;
     tb[2]=RED;
     tb[3]=GREEN;
     tb[4]=BLUE;
	 if     (E==0)Wire.beginTransmission(111);
	 else if(E==2)Wire.beginTransmission(112);
	 else if(E==4)Wire.beginTransmission(113);
	 else if(E==5)Wire.beginTransmission(114);
	 Wire.write(tb,5);
     Wire.endTransmission();
	}
	else if((E==1)|(E==3))
	{
 
     tb[0]=3;
     tb[1]=0;
     tb[2]=RED;
     tb[3]=GREEN;
     tb[4]=BLUE;
	 if      (E==1)Wire.beginTransmission(111);
	 else if (E==3)Wire.beginTransmission(112);
     Wire.write(tb,5);
     Wire.endTransmission();
	}
	delay(1);
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
float get_Ligth_Sensor_value_Smart_City(uint8_t add)
{
  float f_ret;
  uint16_t ADC_value=1023,temp;
  uint64_t soil_humidity_timer=0;
  
  {
   if (millis() - soil_humidity_timer > 100) {
   wdt_enable(WDTO_2S);
   soil_humidity_timer= millis();
   if     ((add==0))Wire.requestFrom(111,5);
   else if((add==1))Wire.requestFrom(112,5);
   else if((add==2))Wire.requestFrom(113,5);
   else if((add==3))Wire.requestFrom(114,5);
   if (Wire.available()) {
   uint8_t i2cdata[6];
   Wire.readBytes(i2cdata,5);
    ADC_value=i2cdata[1];
	ADC_value=ADC_value<<8;
	ADC_value+=i2cdata[2];
   }wdt_disable();}	  
   ADC_value=1023-ADC_value; 
     f_ret=	ADC_value;
	 f_ret=f_ret*100;
	 f_ret=f_ret/1023;
	 delay(20);
	 return f_ret;
  }  	
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
float get_MQ2_Sensor_value_Smart_City(uint8_t add)
{
  float f_ret;
  uint16_t ADC_value=1023,temp;
  uint64_t soil_humidity_timer=0;
  if((add==0)){
   if (millis() - soil_humidity_timer > 100) {
   wdt_enable(WDTO_2S);
   soil_humidity_timer= millis();
   Wire.requestFrom(111,5);
   if (Wire.available()) {
   uint8_t i2cdata[6];
   Wire.readBytes(i2cdata,5);
    ADC_value=i2cdata[3];
	ADC_value=ADC_value<<8;
	ADC_value+=i2cdata[4];
   }wdt_disable();}	  
     f_ret=	ADC_value;
	 delay(20);
	 return f_ret;
  }  	
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
float get_IR_Sensor_value_Smart_City(uint8_t add)
{
  float f_ret;
  uint16_t ADC_value=1023,temp;
  uint64_t soil_humidity_timer=0;
  if((add==0)){
   if (millis() - soil_humidity_timer > 100) {
   wdt_enable(WDTO_2S);
   soil_humidity_timer= millis();
   Wire.requestFrom(112,5);
   if (Wire.available()) {
   uint8_t i2cdata[6];
   Wire.readBytes(i2cdata,5);
    ADC_value=i2cdata[3];
	ADC_value=ADC_value<<8;
	ADC_value+=i2cdata[4];
   }wdt_disable();}	  
     f_ret=	1023-ADC_value;
     delay(20);
	 return f_ret;
  }  	
}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
////////////////////////////////
void play_track_by_name_SMARTHOME(char ADD,char *track_name)
{
   char tb[50];
   char len=strlen(track_name);
   char i;
   unsigned char CRC;
   tb[0]=0xAA;
   tb[1]=0x08;
   tb[2]=len+6;
   tb[3]=0x02;
   tb[4]=0x2f;
   for(i=0;i<len;i++)
   {
	 tb[5+i]= track_name[i]; 
   }
   tb[5+i]='*';
   tb[6+i]='M';
   tb[7+i]='P';
   tb[8+i]='3';
   CRC=0;
   for(i=0;i<len+9;i++)
   {
	 CRC+=tb[i]; 
   }
   tb[i]=CRC;    
   if(ADD==0)Wire.beginTransmission(113);
   if(ADD==1)Wire.beginTransmission(114);
   Wire.write(tb,len+10);
   Wire.endTransmission();
   delay(1);
}
////////////////////////////////
void SET_MATRIX_SMARTHOME_PARKING(char ADD,char X,char Y,char Status)
{

     char tb[6];
     tb[0]=3;
	  Y=7-Y;
     tb[1]=Y;
     tb[2]=X;
     tb[3]=Status;
     tb[4]=0;
     Wire.beginTransmission(115);
	 
     Wire.write(tb,5);
     Wire.endTransmission();

	delay(1);
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void dot_matris_clear_all_smart(char ADD){
	 char tb[6];
     tb[0]=4;
     tb[1]=0;
     tb[2]=0;
     tb[3]=0;
     tb[4]=0;
     Wire.beginTransmission(115);
	 
     Wire.write(tb,5);
     Wire.endTransmission();

	delay(1);
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void write_to_sevensegment_Text_V2_smart(char *str,char add)
{
  int8_t len,i;
  char send_buff[5];
  len=strlen(str);
  if     (len==0) {send_buff[1]=' ';   send_buff[2]=' '   ;send_buff[3]=' '   ;send_buff[4]=' ';}
  else if(len==1) {send_buff[1]=str[0];send_buff[2]=' '   ;send_buff[3]=' '   ;send_buff[4]=' ';}
  else if(len==2) {send_buff[1]=str[0];send_buff[2]=str[1];send_buff[3]=' '   ;send_buff[4]=' ';}
  else if(len==3) {send_buff[1]=str[0];send_buff[2]=str[1];send_buff[3]=str[2];send_buff[4]=' ';}
  else            {send_buff[1]=str[0];send_buff[2]=str[1];send_buff[3]=str[2];send_buff[4]=str[3];send_buff[5]=0;}
   send_buff[0]=2;
   Wire.beginTransmission(115);
   Wire.write(send_buff,5);
   Wire.endTransmission();
   delay(1);
}
//////////////////////////////////////////
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void write_to_sevensegment_V2_smart(float F_number,char add)
{
  int8_t f_point;
  int32_t segs_value,fb;
  int16_t point;
  int16_t integer;
  char  seg_value_buffer[6];
  DATA_CONVERTER conv;
  
  
  if(F_number<0)
  {
	  if((F_number<-1)&(F_number>-10)){fb=F_number*100;F_number=fb;F_number=F_number/100;}
	  if((F_number<-10)&(F_number>-100)){fb=F_number*10;F_number=fb;F_number=F_number/10;}
	  if((F_number<-100)){fb=F_number;F_number=fb;F_number=F_number;}
  }
  segs_value=F_number*1000;
  
  
  
  //if(F_number<0){seg_value_buffer[5] = 1; segs_value *= -1;}else {seg_value_buffer[5] = 0;}
  if (segs_value > 9999999) segs_value = 10000000;
  if (segs_value < -999999) segs_value = -1000000;
  
  conv.L=segs_value;
  //if(F_number < 0) {seg_value_buffer[3] = 1; segs_value *= -1;}
  seg_value_buffer[0] =  1;
  seg_value_buffer[1] = conv.BI[0];
  seg_value_buffer[2] = conv.BI[1];
  seg_value_buffer[3] = conv.BI[2];
  seg_value_buffer[4] = conv.BI[3];


  Wire.beginTransmission(115);
  Wire.write(seg_value_buffer,6);
  Wire.endTransmission();

  delay(1);
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void SET_LED_STATE_SMART_CT(char ADD,char STATE)
{
	 char tb[6];
     tb[0]=ADD;
	 if     (STATE==3){tb[1]=1;tb[2]=1;}
	 else if(STATE==2){tb[1]=0;tb[2]=1;}
	 else if(STATE==1){tb[1]=1;tb[2]=0;}
	 else        {tb[1]=0;tb[2]=0;}
     tb[3]=0;
     tb[4]=0;
     Wire.beginTransmission(116);
	 
     Wire.write(tb,5);
     Wire.endTransmission();

	

  delay(1);
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
float get_smart_park_ligth_sensor_(uint8_t add)
{
  float f_ret;
  uint16_t ADC_value=1023,temp;
  uint64_t soil_humidity_timer=0;
  uint8_t i2cdata[12];
  if(add<1)add=1;
  add=add-1;
  add=add*2;
  if (millis() - soil_humidity_timer > 100) {
   wdt_enable(WDTO_2S);
   soil_humidity_timer= millis();
   Wire.requestFrom(116,12);
   if (Wire.available()) {
   Wire.readBytes(i2cdata,12);
    ADC_value=i2cdata[1+add];
	ADC_value=ADC_value<<8;
	ADC_value+=i2cdata[0+add];
   }wdt_disable();}	  
     f_ret=	1023-ADC_value;
	 f_ret=f_ret*100;
	 f_ret=f_ret/1023;
	//f_ret= ADC_value;
     delay(1);
	 return f_ret;	
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void Write_Text_to_Matris_Smart_city(uint8_t add,char *str,char speed)
{
     char tb[50];
	 uint8_t len ;
	 int i;
	 len=strlen(str);
     tb[0]=5;
	 tb[1]=speed;
	 tb[2]=len;

	 
	  for(i=0;i<len;i++){ 
	   tb[(3+i)]=str[i];
	    
	   }
	  //tb[i]=0;
	 //Serial.println(tb);
	 
     Wire.beginTransmission(115);	 
     Wire.write(tb,len+3);
     Wire.endTransmission();
     delay(1);	
}
//////////////////////////////////////////
#endif