#ifndef I2A_IR_v1_0
#define I2A_IR_v1_0

#include <Wire.h>
#include <avr/wdt.h>
void INFRARED_reciver_sender_INIT(uint8_t ADD)
{
 Wire.begin();	
}
//////////////////////////////////////////////////
void Save_IR_Signal(uint8_t ADD,uint8_t SLOT)
{
   uint8_t Data_transfare[3];
   Wire.beginTransmission(100);
   Data_transfare[0] = 111;
   Data_transfare[1] = SLOT;
   Wire.write(Data_transfare,2);
   Wire.endTransmission();
}
//////////////////////////////////////////////////
void Send_IR_Signal(uint8_t ADD,uint8_t SLOT)
{
   uint8_t Data_transfare[3];
   Wire.beginTransmission(100);
   Data_transfare[0] = 222;
   Data_transfare[1] = SLOT;
   Wire.write(Data_transfare,2);
   Wire.endTransmission();
}
//////////////////////////////////////////////////




















#endif
