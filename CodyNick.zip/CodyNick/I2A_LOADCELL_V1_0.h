#define i2a_LOADCELL_V1_0_H 
long LOADCELL_ADC_VALUE_I2A=56;
float DEAD_WEIGTH_LOADCELL=0;
float global_wegth_value_=0;
////////////////////////////////////////////////////
float Return_LOADCELL_value_V1_0(char mode)
{
	float f;
	f=LOADCELL_ADC_VALUE_I2A;
    f=(f*0.00147)+3.94118;
	f=f+DEAD_WEIGTH_LOADCELL;
	global_wegth_value_=f;
	return f;
}
////////////////////////////////////////////////////
void SET_LOADCELL_TARE(char e)
{
  DEAD_WEIGTH_LOADCELL+=0-global_wegth_value_;	
 
}
////////////////////////////////////////////////////
void GET_LOADCELL_ADC_value_V1_0(char e)
{
  	uint64_t ADC_TIMER=0;
   long recive;
    //LOADCELL_ADC_VALUE_I2A=233;
   if (millis() - ADC_TIMER > 2000) {
   wdt_enable(WDTO_2S);
   ADC_TIMER= millis();
   Wire.requestFrom(82, 4);
   while (Wire.available()) {
   uint8_t i2cdata[4];
   Wire.readBytes(i2cdata,4);
   
   recive=i2cdata[0];
   recive=recive<<8;
   recive+=i2cdata[1];
   recive=recive<<8;
   recive+=i2cdata[2];
   recive=recive<<8;
   recive+=i2cdata[3];
   
   recive=recive>>8;
   LOADCELL_ADC_VALUE_I2A=recive;

}wdt_disable();
}	
	
}