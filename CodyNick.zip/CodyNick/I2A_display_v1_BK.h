#define SEG_A      6  //11
#define SEG_B      7  //7
#define SEG_C      8  //4
#define SEG_D      9  //2
#define SEG_E      15 //1
#define SEG_F      11 //10
#define SEG_G      12 //5
#define SEG_P      13 //3
#define SEG_SEL4   14 //12
#define SEG_SEL3   3  //9  
#define SEG_SEL2   4  //8  
#define SEG_SEL1   5  //6  
void print_LCD_(char x,char y,char com ,char *str){
	char LCD_DATA_[60];
	char pos;
    if((x>=16)&(y==0)&(x<32)){x=x-16;y=1;}
	if(x>31)return;
	if(y>1)return;
	
	snprintf(LCD_DATA_+3,50, "%s ", str);
	Wire.beginTransmission(95);
    LCD_DATA_[0]=x;
    LCD_DATA_[1]=y;
	LCD_DATA_[2]=com;
    Wire.write(LCD_DATA_,3+strlen(3+LCD_DATA_));
    Wire.endTransmission();
	delay(100);	
	
	
	
	if(((strlen(str)+x)>16)&(y==0))
	{
	 pos=(strlen(str)+x)-16;
	 snprintf(LCD_DATA_+3,50, "%s ", str+16-x);
	 Wire.beginTransmission(95);
     LCD_DATA_[0]=0;
     LCD_DATA_[1]=1;
	 LCD_DATA_[2]=0;
     Wire.write(LCD_DATA_,3+strlen(3+LCD_DATA_));
     Wire.endTransmission();
	 delay(100);	
	}
	
}
void print_LCD_(char x,char y,char com ,float fdata){
	char LCD_DATA_[60];
	long L=fdata*1000;
    if((x>=16)&(y==0)&(x<32)){x=x-16;y=1;}
	if(x>31)return;
	if(y>1)return;
	if(L<0)
	{
	 L=L*-1;	
	 sprintf(LCD_DATA_+3, "-%li.%li ",L/1000,L%1000);
	}
	else
	{
	 sprintf(LCD_DATA_+3, "%li.%li ",L/1000,L%1000);
	}
	Wire.beginTransmission(95);
    LCD_DATA_[0]=x;
    LCD_DATA_[1]=y;
	LCD_DATA_[2]=com;
    Wire.write(LCD_DATA_,3+strlen(3+LCD_DATA_));
    Wire.endTransmission();
	delay(100);
}
void print_LCD_(char x,char y,char com ,long fdata){
    if((x>=16)&(y==0)&(x<32)){x=x-16;y=1;}
	if(x>31)return;
	if(y>1)return;
	char LCD_DATA_[60];
	sprintf(LCD_DATA_+3, "%li", (int)fdata);
	Wire.beginTransmission(95);
    LCD_DATA_[0]=x;
    LCD_DATA_[1]=y;
	LCD_DATA_[2]=com;
    Wire.write(LCD_DATA_,3+strlen(3+LCD_DATA_));
    Wire.endTransmission();
	delay(100);
}
void print_LCD_(char x,char y,char com ,double fdata){
	char LCD_DATA_[60];
    if((x>=16)&(y==0)&(x<32)){x=x-16;y=1;}
	if(x>31)return;
	if(y>1)return;
	sprintf(LCD_DATA_+3, "%d",fdata);
	Wire.beginTransmission(95);
    LCD_DATA_[0]=x;
    LCD_DATA_[1]=y;
	LCD_DATA_[2]=com;
    Wire.write(LCD_DATA_,3+strlen(3+LCD_DATA_));
    Wire.endTransmission();
	delay(100);
}
void print_LCD_(char x,char y,char com ,int fdata){
	char LCD_DATA_[60];
    if((x>=16)&(y==0)&(x<32)){x=x-16;y=1;}
	if(x>31)return;
	if(y>1)return;
	sprintf(LCD_DATA_+3, "%i",fdata);
	Wire.beginTransmission(95);
    LCD_DATA_[0]=x;
    LCD_DATA_[1]=y;
	LCD_DATA_[2]=com;
    Wire.write(LCD_DATA_,3+strlen(3+LCD_DATA_));
    Wire.endTransmission();
	delay(100);
}
void print_LCD_(char x,char y,char com ,uint32_t fdata){
	char LCD_DATA_[60];
    if((x>=16)&(y==0)&(x<32)){x=x-16;y=1;}
	if(x>31)return;
	if(y>1)return;
	sprintf(LCD_DATA_+3, "%lu",fdata);
	Wire.beginTransmission(95);
    LCD_DATA_[0]=x;
    LCD_DATA_[1]=y;
	LCD_DATA_[2]=com;
    Wire.write(LCD_DATA_,3+strlen(3+LCD_DATA_));
    Wire.endTransmission();
	delay(100);
}
void print_LCD_(char x,char y,char com ,uint16_t fdata){
	char LCD_DATA_[60];
    if((x>=16)&(y==0)&(x<32)){x=x-16;y=1;}
	if(x>31)return;
	if(y>1)return;
	sprintf(LCD_DATA_+3, "%u",fdata);
	Wire.beginTransmission(95);
    LCD_DATA_[0]=x;
    LCD_DATA_[1]=y;
	LCD_DATA_[2]=com;
    Wire.write(LCD_DATA_,3+strlen(3+LCD_DATA_));
    Wire.endTransmission();
	delay(100);
}
void print_LCD_CLEAR_(void){
	char LCD_DATA_[60];
	Wire.beginTransmission(95);
    LCD_DATA_[0]=0;
    LCD_DATA_[1]=0;
	LCD_DATA_[2]=1;
	LCD_DATA_[3]=1;
	LCD_DATA_[3]=1;
    Wire.write(LCD_DATA_,5);
    Wire.endTransmission();
	delay(100);
}

int32_t segs_value = 1234, segs_value_sign = 0;
int8_t point_number = 1;
char seg_mode = 1;
char Enable_Internal_seven_Segment = 0;
char internal_segment = 0;
char  seg_value_i2c_map[4] = {15,60,61,0};// alone - TempSeg-UltraSeg
char seg_value[4];
int32_t number4send;
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void write_to_sevensegment(float input_value,char add)
{
  number4send = (int32_t) ((input_value)*1000.0);
  if (number4send > 9999999) number4send = 10000000;
  if (number4send < -999999) number4send = -1000000;
  seg_value[3] = 0;
  if(number4send < 0) {seg_value[3] = 1; number4send *= -1;}
  seg_value[0] = (number4send) & 0xff;
  seg_value[1] = (number4send >> 8) & 0xff;
  seg_value[2] = (number4send >> 16) & 0xff;
  if(add<3)
  {
   Wire.beginTransmission(seg_value_i2c_map[add]);
   Wire.write(seg_value,4);
   Wire.endTransmission();
  }
  else if(add==4)
  {
   Wire.beginTransmission(98);
   Wire.write(seg_value,4);
   Wire.endTransmission();
  }
  else 
  {
	segs_value= number4send; 
	if(seg_value[3] == 1)
	{
		segs_value_sign=1;
	}
	else 
	{
		segs_value_sign=0;
	}
  }
  delay(10);
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void write_to_sevensegment(int input_value,char add)
{
  number4send = (int32_t) ((input_value)*1000.0);
  if (number4send > 9999999) number4send = 10000000;
  if (number4send < -999999) number4send = -1000000;
  seg_value[3] = 0;
  if(number4send < 0) {seg_value[3] = 1; number4send *= -1;}
  seg_value[0] = (number4send) & 0xff;
  seg_value[1] = (number4send >> 8) & 0xff;
  seg_value[2] = (number4send >> 16) & 0xff;
  if(add<3)
  {
   Wire.beginTransmission(seg_value_i2c_map[add]);
   Wire.write(seg_value,4);
   Wire.endTransmission();
  }
  else if(add==4)
  {
   Wire.beginTransmission(98);
   Wire.write(seg_value,4);
   Wire.endTransmission();
  }
  else 
  {
	segs_value= number4send; 
	if(seg_value[3] == 1)
	{
		segs_value_sign=1;
	}
	else 
	{
		segs_value_sign=0;
	}
  }
  delay(10);
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void write_to_sevensegment(char *str,char add)
{
  int32_t Data ;
  int8_t len,i;
  char send_buff[4];
  
  len=strlen(str);
  if(len==0) {str[0]=' ';str[1]=' ';str[2]=' ';str[3]=' ';}
  if(len==1) {str[1]=' ';str[2]=' ';str[3]=' ';}
  if(len==2) {str[2]=' ';str[3]=' ';}
  if(len==3) {str[3]=' ';}
  
  Data=str[0];
  Data=Data<<8;
  Data|=str[1];
  Data=Data<<8;   
  Data|=str[2];
  Data=Data<<8;   
  Data|=str[3];
 
  

       
    //  Serial.println(Data);  
  
  Data+=10000000;
  
  send_buff[0]=Data>>24;
  send_buff[1]=Data>>16;
  send_buff[2]=Data>>8;
  send_buff[3]=Data;
  
   if(add==4)
  {
   Wire.beginTransmission(98);
   Wire.write(send_buff,4);
   Wire.endTransmission();
  }
  
  
  
  
  delay(10);
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

void init_seven_segment(char e)
{
 if((e==3)|(e==5)){
 Enable_Internal_seven_Segment=1;
 pinMode(SEG_A, OUTPUT);
 pinMode(SEG_B, OUTPUT);
 pinMode(SEG_C, OUTPUT);
 pinMode(SEG_D, OUTPUT);
 pinMode(SEG_E, OUTPUT);
 pinMode(SEG_F, OUTPUT);
 pinMode(SEG_G, OUTPUT);
 pinMode(SEG_P, OUTPUT);
 pinMode(SEG_SEL1, OUTPUT);
 pinMode(SEG_SEL2, OUTPUT);
 pinMode(SEG_SEL3, OUTPUT);
 pinMode(SEG_SEL4, OUTPUT);
 cli();
 /*
//set timer1 interrupt at 1Hz
  TCCR1A = 0;// set entire TCCR1A register to 0
  TCCR1B = 0;// same for TCCR1B
  TCNT1  = 0;//initialize counter value to 0
  // set compare match register for 1hz increments
  OCR1A = 0;// = (16*10^6) / (1*1024) - 1 (must be <65536)
  // turn on CTC mode
  TCCR1B |= (1 << WGM12);
  // Set CS10 and CS12 bits for 1024 prescaler
  TCCR1B |= (1 << CS12) | (1 << CS10);  
  // enable timer compare interrupt
  TIMSK1 |= (1 << OCIE1A);
*/  
TCCR1A=(0<<COM1A1) | (0<<COM1A0) | (0<<COM1B1) | (0<<COM1B0) | (0<<WGM11) | (0<<WGM10);
TCCR1B=(0<<ICNC1) | (0<<ICES1) | (0<<WGM13) | (0<<WGM12) | (0<<CS12) | (0<<CS11) | (1<<CS10);
TCNT1H=0xFF;
TCNT1L=0xF8;
ICR1H=0x00;
ICR1L=0x00;
OCR1AH=0x00;
OCR1AL=0x00;
OCR1BH=0x00;
OCR1BL=0x00;
// Timer/Counter 2 Interrupt(s) initialization
//TIMSK2=(0<<OCIE2B) | (0<<OCIE2A) | (1<<TOIE2);
 
 sei();
 }
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void setAllSegsHigh() {
  digitalWrite(SEG_A, HIGH);
  digitalWrite(SEG_B, HIGH);
  digitalWrite(SEG_C, HIGH);
  digitalWrite(SEG_D, HIGH);
  digitalWrite(SEG_E, HIGH);
  digitalWrite(SEG_F, HIGH);
  digitalWrite(SEG_G, HIGH);
  digitalWrite(SEG_P, HIGH);
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void setAllSegsLow() {
  digitalWrite(SEG_A, LOW);
  digitalWrite(SEG_B, LOW);
  digitalWrite(SEG_C, LOW);
  digitalWrite(SEG_D, LOW);
  digitalWrite(SEG_E, LOW);
  digitalWrite(SEG_F, LOW);
  digitalWrite(SEG_G, LOW);
  digitalWrite(SEG_P, LOW);
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void num(byte n) {
  //if(n < 0) n = 0;
  //#if defined(seg_mode) 
  //sr.setAllHigh();
  setAllSegsHigh();
  if(seg_mode == 0)
  {
    switch (n) {
      case 0:
        //sr.setAllHigh(); // 0
        digitalWrite(SEG_A, LOW);
        digitalWrite(SEG_B, LOW);
        digitalWrite(SEG_C, LOW);
        digitalWrite(SEG_D, LOW);
        digitalWrite(SEG_E, LOW);
        digitalWrite(SEG_F, LOW);
        break;
      case 1:
        //sr.setAllHigh(); // 1
        digitalWrite(SEG_B, LOW);
        digitalWrite(SEG_C, LOW);
        break;
      case 2:
        //sr.setAllHigh(); // 2
        digitalWrite(SEG_A, LOW);
        digitalWrite(SEG_B, LOW);
        digitalWrite(SEG_G, LOW);
        digitalWrite(SEG_E, LOW);
        digitalWrite(SEG_D, LOW);
        break;
      case 3:
        //sr.setAllHigh(); // 3
        digitalWrite(SEG_A, LOW);
        digitalWrite(SEG_B, LOW);
        digitalWrite(SEG_G, LOW);
        digitalWrite(SEG_C, LOW);
        digitalWrite(SEG_D, LOW);
        break;
      case 4:
        //sr.setAllHigh(); // 4
        digitalWrite(SEG_F, LOW);
        digitalWrite(SEG_B, LOW);
        digitalWrite(SEG_G, LOW);
        digitalWrite(SEG_C, LOW);
        break;
      case 5:
        //sr.setAllHigh(); // 5
        digitalWrite(SEG_A, LOW);
        digitalWrite(SEG_F, LOW);
        digitalWrite(SEG_G, LOW);
        digitalWrite(SEG_C, LOW);
        digitalWrite(SEG_D, LOW);
        break;
      case 6:
        //sr.setAllHigh(); // 6
        digitalWrite(SEG_A, LOW);
        digitalWrite(SEG_F, LOW);
        digitalWrite(SEG_G, LOW);
        digitalWrite(SEG_C, LOW);
        digitalWrite(SEG_D, LOW);
        digitalWrite(SEG_E, LOW);
        break;
      case 7:
        //sr.setAllHigh(); // 7
        digitalWrite(SEG_A, LOW);
        digitalWrite(SEG_B, LOW);
        digitalWrite(SEG_C, LOW);
        break;
      case 8:
        //sr.setAllHigh(); // 8
        digitalWrite(SEG_A, LOW);
        digitalWrite(SEG_B, LOW);
        digitalWrite(SEG_C, LOW);
        digitalWrite(SEG_D, LOW);
        digitalWrite(SEG_E, LOW);
        digitalWrite(SEG_F, LOW);
        digitalWrite(SEG_G, LOW);
        break;
      case 9:
        //sr.setAllHigh(); // 9
        digitalWrite(SEG_A, LOW);
        digitalWrite(SEG_B, LOW);
        digitalWrite(SEG_C, LOW);
        digitalWrite(SEG_D, LOW);
        digitalWrite(SEG_F, LOW);
        digitalWrite(SEG_G, LOW);
        break;
    case 16:  //dash
        digitalWrite(SEG_G, LOW);
    break; 
    
    case 17:  //OFF
    break; 

      default:
        //sr.setAllHigh();
        break;  
    }
  }
  //#else
  else
  {
    //sr.setAllLow();
    setAllSegsLow();
    switch (n) {
      case 0:
        //sr.setAllLow(); // 0
        digitalWrite(SEG_A, HIGH);
        digitalWrite(SEG_B, HIGH);
        digitalWrite(SEG_C, HIGH);
        digitalWrite(SEG_D, HIGH);
        digitalWrite(SEG_E, HIGH);
        digitalWrite(SEG_F, HIGH);
        break;
      case 1:
        //sr.setAllLow(); // 1
        digitalWrite(SEG_B, HIGH);
        digitalWrite(SEG_C, HIGH);
        break;
      case 2:
        //sr.setAllLow(); // 2
        digitalWrite(SEG_A, HIGH);
        digitalWrite(SEG_B, HIGH);
        digitalWrite(SEG_G, HIGH);
        digitalWrite(SEG_E, HIGH);
        digitalWrite(SEG_D, HIGH);
        break;
      case 3:
        //sr.setAllLow(); // 3
        digitalWrite(SEG_A, HIGH);
        digitalWrite(SEG_B, HIGH);
        digitalWrite(SEG_G, HIGH);
        digitalWrite(SEG_C, HIGH);
        digitalWrite(SEG_D, HIGH);
        break;
      case 4:
        //sr.setAllLow(); // 4
        digitalWrite(SEG_F, HIGH);
        digitalWrite(SEG_B, HIGH);
        digitalWrite(SEG_G, HIGH);
        digitalWrite(SEG_C, HIGH);
        break;
      case 5:
        //sr.setAllLow(); // 5
        digitalWrite(SEG_A, HIGH);
        digitalWrite(SEG_F, HIGH);
        digitalWrite(SEG_G, HIGH);
        digitalWrite(SEG_C, HIGH);
        digitalWrite(SEG_D, HIGH);
        break;
      case 6:
        //sr.setAllLow(); // 6
        digitalWrite(SEG_A, HIGH);
        digitalWrite(SEG_F, HIGH);
        digitalWrite(SEG_G, HIGH);
        digitalWrite(SEG_C, HIGH);
        digitalWrite(SEG_D, HIGH);
        digitalWrite(SEG_E, HIGH);
        break;
      case 7:
        //sr.setAllLow(); // 7
        digitalWrite(SEG_A, HIGH);
        digitalWrite(SEG_B, HIGH);
        digitalWrite(SEG_C, HIGH);
        break;
      case 8:
        //sr.setAllLow(); // 8
        digitalWrite(SEG_A, HIGH);
        digitalWrite(SEG_B, HIGH);
        digitalWrite(SEG_C, HIGH);
        digitalWrite(SEG_D, HIGH);
        digitalWrite(SEG_E, HIGH);
        digitalWrite(SEG_F, HIGH);
        digitalWrite(SEG_G, HIGH);
        break;
      case 9:
        //sr.setAllLow(); // 9
        digitalWrite(SEG_A, HIGH);
        digitalWrite(SEG_B, HIGH);
        digitalWrite(SEG_C, HIGH);
        digitalWrite(SEG_D, HIGH);
        digitalWrite(SEG_F, HIGH);
        digitalWrite(SEG_G, HIGH);
        break; 
    case 16:  //dash
        digitalWrite(SEG_G, HIGH);
    break; 
    
    case 17:  //OFF
    break; 

      default:
        //sr.setAllLow();
        break;    
    }
  //#endif
  }
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void ond(int i) {
  if (seg_mode == 0)
    digitalWrite(i, HIGH);
  else
    digitalWrite(i, LOW);
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void offd(int i) {
  if (seg_mode == 0)
    digitalWrite(i, LOW);
  else
    digitalWrite(i, HIGH);
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void ondp() {
  if (seg_mode == 0)
    digitalWrite(SEG_P, LOW);
  else
    digitalWrite(SEG_P, HIGH);
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void offdp() {
  if (seg_mode == 0)
    digitalWrite(SEG_P, HIGH);
  else
    digitalWrite(SEG_P, LOW);
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void show_number(void)
{
  int32_t value;
  char dig[5];
  char sign_placed = 0;
  point_number = 4;
  value = segs_value;
   delay(5); 
  offd(SEG_SEL1);
  offd(SEG_SEL2);
  offd(SEG_SEL3);
  offd(SEG_SEL4);
  offdp();

  for (int j = 0; j < 3; j++) { //remove zeros from right side of fraction
    if (value % 10 == 0) {
      value = value / 10;
      point_number--;
    }
  }

    if (segs_value_sign == 0) 
    for (int j = 0; j < 3; j++) { //remove additional fraction digits
      if (value > 9999) {
        value = value / 10;
        point_number--;
      }
    }
  else{
    for (int j = 0; j < 4; j++) {
      if (value > 999) {
        value = value / 10;
        point_number--;
      }
    }
    }
      if (point_number < 1) { //Number can not be shown
    dig[1] = 16; dig[2] = 16; dig[3] = 16; dig[4] = 16; //show ----
  } else{
    dig[1] = value % 10; value = value / 10;

    for (int j = 2; j <5; j++) 
    if (value == 0){
      if (segs_value_sign == 1) {
        if (sign_placed == 1) 
          dig[j] = 17; //OFF
        else {
            dig[j] = 16; //minus sign
            sign_placed = 1;
          }
      } else
          dig[j] = 17; //OFF
    }
    else {
      dig[j] = value % 10; value = value / 10;
    }
  }


  num(dig[1]);
  offdp();
  ond(SEG_SEL1);  delay(5);  offd(SEG_SEL1);

  num(dig[2]);
  if (point_number == 2) {
    ondp();
  }
  ond(SEG_SEL2);  delay(5);  offd(SEG_SEL2); offdp();

  num(dig[3]);
  if (point_number == 3) {
    ondp();
  }
  ond(SEG_SEL3);  delay(5);  offd(SEG_SEL3); offdp();

  num(dig[4]);
  if (point_number == 4) {
    ondp();
  }
  ond(SEG_SEL4);  delay(5);  offd(SEG_SEL4); offdp();
}
