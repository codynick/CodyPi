#include <Wire.h>
#include <avr/wdt.h>

#define DS18B20_PORT    14
/* Thermometer Connections (At your choice) */ 
#define THERM_PORT PORTC 
#define THERM_DDR DDRC 
#define THERM_PIN PINC 
#define THERM_DQ PC0 
/* Utils */ 
#define THERM_INPUT_MODE() THERM_DDR&=~(1<<THERM_DQ) 
#define THERM_OUTPUT_MODE() THERM_DDR|=(1<<THERM_DQ) 
#define THERM_LOW() THERM_PORT&=~(1<<THERM_DQ) 
#define THERM_HIGH() THERM_PORT|=(1<<THERM_DQ)
//////////////////////////////////////////////////////////////////////////////////
#define THERM_CMD_CONVERTTEMP 0x44 
#define THERM_CMD_RSCRATCHPAD 0xbe 
#define THERM_CMD_WSCRATCHPAD 0x4e 
#define THERM_CMD_CPYSCRATCHPAD 0x48 
#define THERM_CMD_RECEEPROM 0xb8 
#define THERM_CMD_RPWRSUPPLY 0xb4 
#define THERM_CMD_SEARCHROM 0xf0 
#define THERM_CMD_READROM 0x33 
#define THERM_CMD_MATCHROM 0x55 
#define THERM_CMD_SKIPROM 0xcc 
#define THERM_CMD_ALARMSEARCH 0xec
//////////////////////////////////////////////////////////////////////////////////
uint8_t therm_reset()
{ 
 uint8_t i;
 //Pull line low and wait for 480uS 
 THERM_LOW(); 
 THERM_OUTPUT_MODE(); 
 delayMicroseconds(480); 
 //Release line and wait for 60uS 
 THERM_INPUT_MODE(); 
 delayMicroseconds(60); 
 //Store line value and wait until the completion of 480uS period 
 i=(THERM_PIN & (1<<THERM_DQ)); 
 delayMicroseconds(420); 
 //Return the value read from the presence pulse (0=OK, 1=WRONG) return i;
}
//////////////////////////////////////////////////////////
void therm_write_bit(uint8_t bit)
{ 
 //Pull line low for 1uS 
 THERM_LOW(); 
 THERM_OUTPUT_MODE(); 
 delayMicroseconds(1); 
 //If we want to write 1, release the line (if not will keep low) 
 if(bit) THERM_INPUT_MODE(); //Wait for 60uS and release the line 
 delayMicroseconds(60); 
 THERM_INPUT_MODE(); 
 }
//////////////////////////////////////////////////////////
uint8_t therm_read_bit(void)
{ 
 uint8_t bit=0; 
 //Pull line low for 1uS 
 THERM_LOW(); 
 THERM_OUTPUT_MODE(); 
 delayMicroseconds(1); 
 //Release line and wait for 14uS 
 THERM_INPUT_MODE(); 
 delayMicroseconds(14); 
 //Read line value 
 if(THERM_PIN&(1<<THERM_DQ)) bit=1; 
 //Wait for 45uS to end and return read value 
 delayMicroseconds(45); 
 return bit; 
}
//////////////////////////////////////////////////////////
uint8_t therm_read_byte(void)
{ 
 uint8_t i=8, n=0; 
 while(i--){
  //Shift one position right and store read value 
  n>>=1; 
  n|=(therm_read_bit()<<7);
  } 
  return n;
} 
//////////////////////////////////////////////////////////
void therm_write_byte(uint8_t byte)
{ 
 uint8_t i=8; 
 while(i--){ 
 //Write actual bit and shift one position right to make the next bit ready 
 therm_write_bit(byte&1); 
 byte>>=1; 
 } 
}
//////////////////////////////////////////////////////////
#define THERM_DECIMAL_STEPS_12BIT 625 //.0625 
float therm_read_temperature(void)
{ 
 float f;
 char str[30];
 // Buffer length must be at least 12bytes long! ["+XXX.XXXX C"] 
 uint8_t temperature[2]; 
 int8_t digit; uint16_t decimal; 
 //Reset, skip ROM and start temperature conversion 
 therm_reset(); 
 therm_write_byte(THERM_CMD_SKIPROM); 
 therm_write_byte(THERM_CMD_CONVERTTEMP); 
 //Wait until conversion is complete 
 while(!therm_read_bit()); 
 //Reset, skip ROM and send command to read Scratchpad 
 therm_reset(); 
 therm_write_byte(THERM_CMD_SKIPROM); 
 therm_write_byte(THERM_CMD_RSCRATCHPAD); 
 //Read Scratchpad (only 2 first bytes) 
 temperature[0]=therm_read_byte(); 
 temperature[1]=therm_read_byte(); 
 therm_reset(); 
 //Store temperature integer digits and decimal digits 
 digit=temperature[0]>>4; 
 digit|=(temperature[1]&0x7)<<4; 
 //Store decimal digits 
 decimal=temperature[0]&0xf; 
 decimal*=THERM_DECIMAL_STEPS_12BIT; 
 f=decimal;
 f=f/10000;
 f+=digit;
 //Format temperature into a string [+XXX.XXXX C] 
   // sprintf(str, "%+d.%04u C", digit, decimal); 
   // Serial.println(str);
   return f;
 }
//////////////////////////////////////////////////////////

float GET_TEMPERTURE_SENSOR_VALUE(uint8_t ADD)
{
  uint64_t temperature_timer;
  float Rtemperature;
  
  if((ADD==0)|(ADD==1)|(ADD==3)){
  if (millis() - temperature_timer> 1000) {
  wdt_enable(WDTO_2S);
  temperature_timer = millis();
  if     (ADD ==0)
  {
   Wire.requestFrom(10, 2);
  }
  else if(ADD ==1)
  {
   Wire.requestFrom(60, 3);
  }
  else if(ADD ==3)
  {
   Wire.requestFrom(97, 7);
  }
  else if(ADD ==4)
  {
   Wire.requestFrom(98, 4);
  }
  while (Wire.available()) {
  uint8_t temper[8];
  if(ADD==0){
   Wire.readBytes(temper,2);
   Rtemperature= (temper[0] + temper[1] * 255.0) / 10.0;
  }
  if(ADD==1){
   Wire.readBytes(temper,3);
   Rtemperature= (temper[1] + temper[2] * 255.0) / 10.0;
  }
  if(ADD==3){
   Wire.readBytes(temper,7);
   Rtemperature= (temper[6] + temper[5] * 255.0) / 10.0;
   
  }
  if(ADD==4){
   Wire.readBytes(temper,4);
   //Rtemperature= (temper[3] + temper[2] * 255.0) / 10.0;

  }
  }wdt_disable();}
  }
  if(ADD==2){
	  Rtemperature=therm_read_temperature();
  }

  
  return Rtemperature;
}	

