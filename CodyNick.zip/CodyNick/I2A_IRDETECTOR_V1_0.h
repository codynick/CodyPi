#define I2A_IRDETECTOR_V1_0
void IR_detector_initial_(char e)
{
	Wire.begin();
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
float get_IR_detector_(char E)
{

   uint64_t Detector_TIMER=0;
   uint8_t recive1;
   uint8_t recive2;
   float f;
   
   if (millis() - Detector_TIMER > 500) {
   wdt_enable(WDTO_2S);
   Detector_TIMER= millis();
   Wire.requestFrom(93, 2);
   while (Wire.available()) {
   uint8_t i2cdata[8];
   Wire.readBytes(i2cdata,2);
   recive1=i2cdata[0];
   recive2=i2cdata[0];
   
}wdt_disable();
}
 recive1&=1;
 recive2&=1;
 
 if(E==0)f=recive1;
 if(E==1)f=recive2;
 
 return f;
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


