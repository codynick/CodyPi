#ifndef I2A_RFID_v1_0
#define I2A_RFID_v1_0
#include <Wire.h>
#include <avr/wdt.h>
uint32_t RFID_UID=0;
char RFID_i2cdata[21];
uint64_t RFID_timer;
char GET_RFID_UID_DATA(uint8_t e)
{
  if (millis() - RFID_timer> 1000) {
   wdt_enable(WDTO_2S);
   RFID_timer= millis();
   Wire.requestFrom(97, 20);
   delay(500);
   while (Wire.available()) {
	   Wire.readBytes(RFID_i2cdata,20);
	   RFID_UID=(uint8_t)RFID_i2cdata[0];
	   RFID_UID=RFID_UID<<8;
	   RFID_UID|=(uint8_t)RFID_i2cdata[1];
	   RFID_UID=RFID_UID<<8;
	   RFID_UID|=(uint8_t)RFID_i2cdata[2];
	   RFID_UID=RFID_UID<<8;
	   RFID_UID|=(uint8_t)RFID_i2cdata[3];
		wdt_disable();
		return 2;
	  }
  wdt_disable();
  return 1;
  }
  return 0;
  //return RFID_UID;
}
//////////////////////////////////////////////////
void Write_RFID_UID_DATA(char *str)
{
   Wire.beginTransmission(97);
   Wire.write(str,16);
   Wire.endTransmission();
   delay(500);
}
#endif
