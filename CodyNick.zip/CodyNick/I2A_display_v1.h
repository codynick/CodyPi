#include <Arduino.h>
#include <Wire.h>
#include <SoftwareSerial.h>
#define LCD_DELAY 10
void print_LCD_(char x,char y,char com ,char *str){
	char LCD_DATA_[60];
	char pos;
    if((x>=16)&(y==0)&(x<32)){x=x-16;y=1;}
	if(x>31)return;
	if(y>1)return;
	
	snprintf(LCD_DATA_+3,50, "%s ", str);
	Wire.beginTransmission(95);
    LCD_DATA_[0]=x;
    LCD_DATA_[1]=y;
	LCD_DATA_[2]=com;
    Wire.write(LCD_DATA_,3+strlen(3+LCD_DATA_));
    Wire.endTransmission();
	delay(LCD_DELAY);	
	
	
	
	if(((strlen(str)+x)>16)&(y==0))
	{
	 pos=(strlen(str)+x)-16;
	 snprintf(LCD_DATA_+3,50, "%s ", str+16-x);
	 Wire.beginTransmission(95);
     LCD_DATA_[0]=0;
     LCD_DATA_[1]=1;
	 LCD_DATA_[2]=0;
     Wire.write(LCD_DATA_,3+strlen(3+LCD_DATA_));
     Wire.endTransmission();
	 delay(LCD_DELAY);	
	}
	
}
void print_LCD_(char x,char y,char com ,float fdata){
	char LCD_DATA_[60];
	long L=fdata*1000;
    if((x>=16)&(y==0)&(x<32)){x=x-16;y=1;}
	if(x>31)return;
	if(y>1)return;
	if(L<0)
	{
	 L=L*-1;	
	 sprintf(LCD_DATA_+3, "-%li.%li ",L/1000,L%1000);
	}
	else
	{
	 sprintf(LCD_DATA_+3, "%li.%li ",L/1000,L%1000);
	}
	Wire.beginTransmission(95);
    LCD_DATA_[0]=x;
    LCD_DATA_[1]=y;
	LCD_DATA_[2]=com;
    Wire.write(LCD_DATA_,3+strlen(3+LCD_DATA_));
    Wire.endTransmission();
	delay(LCD_DELAY);
}
void print_LCD_(char x,char y,char com ,long fdata){
    if((x>=16)&(y==0)&(x<32)){x=x-16;y=1;}
	if(x>31)return;
	if(y>1)return;
	char LCD_DATA_[60];
	sprintf(LCD_DATA_+3, "%li", (int)fdata);
	Wire.beginTransmission(95);
    LCD_DATA_[0]=x;
    LCD_DATA_[1]=y;
	LCD_DATA_[2]=com;
    Wire.write(LCD_DATA_,3+strlen(3+LCD_DATA_));
    Wire.endTransmission();
	delay(LCD_DELAY);
}
void print_LCD_(char x,char y,char com ,double fdata){
	char LCD_DATA_[60];
    if((x>=16)&(y==0)&(x<32)){x=x-16;y=1;}
	if(x>31)return;
	if(y>1)return;
	sprintf(LCD_DATA_+3, "%d",fdata);
	Wire.beginTransmission(95);
    LCD_DATA_[0]=x;
    LCD_DATA_[1]=y;
	LCD_DATA_[2]=com;
    Wire.write(LCD_DATA_,3+strlen(3+LCD_DATA_));
    Wire.endTransmission();
	delay(LCD_DELAY);
}
void print_LCD_(char x,char y,char com ,int fdata){
	char LCD_DATA_[60];
    if((x>=16)&(y==0)&(x<32)){x=x-16;y=1;}
	if(x>31)return;
	if(y>1)return;
	sprintf(LCD_DATA_+3, "%i",fdata);
	Wire.beginTransmission(95);
    LCD_DATA_[0]=x;
    LCD_DATA_[1]=y;
	LCD_DATA_[2]=com;
    Wire.write(LCD_DATA_,3+strlen(3+LCD_DATA_));
    Wire.endTransmission();
	delay(LCD_DELAY);
}
void print_LCD_(char x,char y,char com ,uint32_t fdata){
	char LCD_DATA_[60];
    if((x>=16)&(y==0)&(x<32)){x=x-16;y=1;}
	if(x>31)return;
	if(y>1)return;
	sprintf(LCD_DATA_+3, "%lu",fdata);
	Wire.beginTransmission(95);
    LCD_DATA_[0]=x;
    LCD_DATA_[1]=y;
	LCD_DATA_[2]=com;
    Wire.write(LCD_DATA_,3+strlen(3+LCD_DATA_));
    Wire.endTransmission();
	delay(LCD_DELAY);
}
void print_LCD_(char x,char y,char com ,uint16_t fdata){
	char LCD_DATA_[60];
    if((x>=16)&(y==0)&(x<32)){x=x-16;y=1;}
	if(x>31)return;
	if(y>1)return;
	sprintf(LCD_DATA_+3, "%u",fdata);
	Wire.beginTransmission(95);
    LCD_DATA_[0]=x;
    LCD_DATA_[1]=y;
	LCD_DATA_[2]=com;
    Wire.write(LCD_DATA_,3+strlen(3+LCD_DATA_));
    Wire.endTransmission();
	delay(LCD_DELAY);
}
void print_LCD_CLEAR_(void){
	char LCD_DATA_[60];
	Wire.beginTransmission(95);
    LCD_DATA_[0]=0;
    LCD_DATA_[1]=0;
	LCD_DATA_[2]=1;
	LCD_DATA_[3]=1;
	LCD_DATA_[4]=1;
    Wire.write(LCD_DATA_,5);
    Wire.endTransmission();
	delay(LCD_DELAY);
}
