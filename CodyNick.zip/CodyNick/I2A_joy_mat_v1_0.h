char joymat_i2c_add[2]={9,70};
char matrix_led[55];
void to_chars(char *str){
	snprintf(matrix_led+2,50, "%s ", str);
}
void to_chars(float fdata){
	sprintf(matrix_led+2, "%d ", (int)fdata);
}
void to_chars(double fdata){
	sprintf(matrix_led+2, "%d ", (int)fdata);
}
void to_chars(int data){
	snprintf(matrix_led+2,50, "%d ", data);
}
void set_dot_mat_point(uint8_t Dev_num,uint8_t ON_OFF,uint8_t XXX,uint8_t YYY)
{
	uint8_t X,Y;
  if(Dev_num==1)
  {	  
   X=YYY;
   Y=XXX;
   X=7-X;
   Wire.beginTransmission(joymat_i2c_add[Dev_num]);
   matrix_led[0]=1;
   matrix_led[1]=(int)X;
   matrix_led[2]=(int)Y;
   matrix_led[3]=ON_OFF;
   Wire.write(matrix_led,4);
   Wire.endTransmission();
   delay(5);	
  }
  if(Dev_num==0)
  {	  
   X=YYY;
   Y=XXX;
   X=7-X;
   Wire.beginTransmission(joymat_i2c_add[Dev_num]);
   matrix_led[0]=1;
   matrix_led[1]=(int)XXX;
   matrix_led[2]=(int)YYY;
   matrix_led[3]=ON_OFF;
   Wire.write(matrix_led,4);
   Wire.endTransmission();
   delay(5);	
  }
  
}
/////////////////////////////////
void dot_matris_clear_all(uint8_t Dev_num)
{
  Wire.beginTransmission(joymat_i2c_add[Dev_num]);
  matrix_led[0]=2;
  matrix_led[1]=8;
  matrix_led[2]=0;
  matrix_led[3]=0;
  Wire.write(matrix_led,4);
  Wire.endTransmission();
}
////////////////////////////////