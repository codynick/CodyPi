void play_track_(char track_numer)
{
   char tb[3];
   tb[0]=0;
   tb[1]=track_numer;
   Wire.beginTransmission(84);
   Wire.write(tb,2);
   Wire.endTransmission();
   delay(5);
}
////////////////////////////////
void play_track_by_name(char *track_name)
{
   char tb[50];
   char len=strlen(track_name);
   char i;
   unsigned char CRC;
   tb[0]=0xAA;
   tb[1]=0x08;
   tb[2]=len+6;
   tb[3]=0x02;
   tb[4]=0x2f;
   for(i=0;i<len;i++)
   {
	 tb[5+i]= track_name[i]; 
   }
   tb[5+i]='*';
   tb[6+i]='M';
   tb[7+i]='P';
   tb[8+i]='3';
   CRC=0;
   for(i=0;i<len+9;i++)
   {
	 CRC+=tb[i]; 
   }
   tb[i]=CRC; 
   
   Wire.beginTransmission(84);
   Wire.write(tb,len+10);
   Wire.endTransmission();
   delay(5);
}


