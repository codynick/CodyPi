#ifndef I2A_internet_IOT_______V1
#define I2A_internet_IOT_______V1
#include <Arduino.h>
#include <Wire.h>
#include <SoftwareSerial.h>
#include <Wire.h>
#include <avr/wdt.h>
byte rbdata[5];
union Converting_datatype {
   long L;
   float F;
   char B[4];
} convert_;  
////////////////////////////////////////////////////////////////
void IOT_INIT___________(void){
 Wire.begin();
}
////////////////////////////////////////////////////////////////
void Set_IOT_Text_(char *str_button,int button_number){
}
////////////////////////////////////////////////////////////////
void Set_IOT_Lable_(char *str_button,int button_number){	
  char i2cdata[30],i;
  i2cdata[0]=0xA1;
  i2cdata[1]=button_number;
  strcpy(i2cdata+2, str_button);
  Wire.beginTransmission(117);
  Wire.write(i2cdata,20);
  Wire.endTransmission();
}
////////////////////////////////////////////////////////////////
void Set_IOT_3value_(float f1,float f2,float f3){
  char i2cdata[30],i;
  i2cdata[0]=0xF1;
  convert_.F=f1;
  
  
  i2cdata[1]=convert_.B[0];
  i2cdata[2]=convert_.B[1];
  i2cdata[3]=convert_.B[2];
  i2cdata[4]=convert_.B[3];
  convert_.F=f2;
  i2cdata[5]=convert_.B[0];
  i2cdata[6]=convert_.B[1];
  i2cdata[7]=convert_.B[2];
  i2cdata[8]=convert_.B[3];
  convert_.F=f3;
  i2cdata[9]=convert_.B [0];
  i2cdata[10]=convert_.B[1];
  i2cdata[11]=convert_.B[2];
  i2cdata[12]=convert_.B[3];
  Wire.beginTransmission(117);
  Wire.write(i2cdata,20);
  Wire.endTransmission();


}
////////////////////////////////////////////////////////////////
void Set_IOT_6value_(float f1,float f2,float f3,float f4,float f5,float f6){
  char i2cdata[30],i;
  i2cdata[0]=0xF1;
  convert_.F=f1;

  i2cdata[1]=convert_.B[0];
  i2cdata[2]=convert_.B[1];
  i2cdata[3]=convert_.B[2];
  i2cdata[4]=convert_.B[3];
  convert_.F=f2;
  i2cdata[5]=convert_.B[0];
  i2cdata[6]=convert_.B[1];
  i2cdata[7]=convert_.B[2];
  i2cdata[8]=convert_.B[3];
  convert_.F=f3;
  i2cdata[9]=convert_.B [0];
  i2cdata[10]=convert_.B[1];
  i2cdata[11]=convert_.B[2];
  i2cdata[12]=convert_.B[3];
  convert_.F=f4;
  i2cdata[13]=convert_.B[0];
  i2cdata[14]=convert_.B[1];
  i2cdata[15]=convert_.B[2];
  i2cdata[16]=convert_.B[3];
  convert_.F=f5;
  i2cdata[17]=convert_.B[0];
  i2cdata[18]=convert_.B[1];
  i2cdata[19]=convert_.B[2];
  i2cdata[20]=convert_.B[3];
  convert_.F=f6;
  i2cdata[21]=convert_.B[0];
  i2cdata[22]=convert_.B[1];
  i2cdata[23]=convert_.B[2];
  i2cdata[24]=convert_.B[3];
    
  Wire.beginTransmission(117);
  Wire.write(i2cdata,25);
  Wire.endTransmission();


}
////////////////////////////////////////////////////////////////
void Set_IOT_value_tag(float f1,char *str){
  char i2cdata[30],i;
  i2cdata[0]=0xF1;
  convert_.F=f1;

  i2cdata[1]=convert_.B[0];
  i2cdata[2]=convert_.B[1];
  i2cdata[3]=convert_.B[2];
  i2cdata[4]=convert_.B[3];
  strcpy(i2cdata+5, str);  
  Wire.beginTransmission(117);
  Wire.write(i2cdata,25);
  Wire.endTransmission();
  //Added by Bornoosh
  delay(300);
  ///////////////////
}
////////////////////////////////////////////////////////////////
long Get_IOT_value_tag(char *str){
  char i2cdata[30],i,counter,junk;
  byte readbackbdata[5], n1 = 0, rx_parity = 0, parity = 0, x;
  long ret_value = 0;
  long recive;
  uint64_t www_iot_timer=0;
  i2cdata[0]=0xF2;
  strcpy(i2cdata+1, str);  
  Wire.beginTransmission(117);
  Wire.write(i2cdata,25);
  Wire.endTransmission();
    delay(100);
    
  //if (millis() - www_iot_timer > 2000) 
  {
  wdt_enable(WDTO_2S);
  www_iot_timer = millis();

//////////////////////////////////////////////////////

  Wire.requestFrom(117, 8);
  i=0;
  delay(10);
  counter=0;
  while (Wire.available()) {
	delay(10);
   readbackbdata[counter]=Wire.read();
   counter++;

  }wdt_disable();}
//added by bornoosh
  delay(100);
////////////////  
  
  /*convert_.B[0]=i2cdata[1];
  convert_.B[1]=i2cdata[2];
  convert_.B[2]=i2cdata[3];
  convert_.B[3]=i2cdata[4];
   
  ret_value = convert_.L;
  ret_value=ret_value;*/
  for (int k = 1; k < 5; k++){
	  x = readbackbdata[k];
	  for (int b = 0; b < 8; b++) {
		n1 += (x % 2);
		x = x >> 1;
		if ((k == 4) && (b == 5)) //only 30 bits contain data 
			break;
		}
	}

  rx_parity = x % 2; //the 31st bit contains rx_parity
  
  if (n1 % 2 == 0)
	  parity = 1;
  
  if (parity == rx_parity) {
	  for (int k = 1; k < 5; k++)
		  rbdata[k] = readbackbdata[k];
  } 
  //else Serial.println("Parity error!!!");

  if (strcmp(str,"Button1") == 0) return (rbdata[1] % 2);
  if (strcmp(str,"Button2") == 0) return ((rbdata[1] >> 1) % 2);
  if (strcmp(str,"Button3") == 0) return ((rbdata[1] >> 2) % 2);
  if (strcmp(str,"Button4") == 0) return ((rbdata[1] >> 3) % 2);
  if (strcmp(str,"Button5") == 0) return ((rbdata[1] >> 4) % 2);
  if (strcmp(str,"Button6") == 0) return ((rbdata[1] >> 5) % 2);
  if (strcmp(str,"Input1") == 0) return (((rbdata[1] >> 6) + (rbdata[2] * 4) + (rbdata[3] % 2)*1024)-1024);
  if (strcmp(str,"Input2") == 0) return (((rbdata[3] >> 1) + ((rbdata[4] % 16) * 128))-1024);
  if (strcmp(str,"Status") == 0) return ((rbdata[4] >>4) % 4);

  return 0;//ret_value;
}
////////////////////////////////////////////////////////////////

char *Get_IOT_Value(int button_number){
}
////////////////////////////////////////////////////////////////
void IOT_Wifi_Reset(void){
	//delay(15000);
	Set_IOT_value_tag(1,"Reset");
}
////////////////////////////////////////////////////////////////
void Set_IOT_SSID____(char *str_button,int button_number){
  char i2cdata[30],i;
  i2cdata[0]=0x91;
  i2cdata[1]=button_number;
  strcpy(i2cdata+2, str_button);
  Wire.beginTransmission(117);
  Wire.write(i2cdata,20);
  Wire.endTransmission();
}
////////////////////////////////////////////////////////////////
void Set_IOT_PASSWORD____(char *str_button,int button_number){
  char i2cdata[30],i;
  i2cdata[0]=0x92;
  i2cdata[1]=button_number;
  strcpy(i2cdata+2, str_button);
  Wire.beginTransmission(117);
  Wire.write(i2cdata,20);
  Wire.endTransmission();
}
////////////////////////////////////////////////////////////////
void Set_IOT_IDKEY____(char *str_button,int button_number){
  char i2cdata[30],i;
  i2cdata[0]=0x93;
  i2cdata[1]=button_number;
  strcpy(i2cdata+2, str_button);
  Wire.beginTransmission(117);
  Wire.write(i2cdata,30);
  Wire.endTransmission();
}
////////////////////////////////////////////////////////////////
char * Get_IOT_STATUS_(int button_number){
 return 0;
}
#endif