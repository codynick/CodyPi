#ifndef I2A_display_v2
#define I2A_display_v2
//////////////////////////////////////////
#define SEG_A      6  //11
#define SEG_B      7  //7
#define SEG_C      8  //4
#define SEG_D      9  //2
#define SEG_E      15 //1
#define SEG_F      11 //10
#define SEG_G      12 //5
#define SEG_P      13 //3
#define SEG_SEL4   14 //12
#define SEG_SEL3   3  //9  
#define SEG_SEL2   4  //8  
#define SEG_SEL1   5  //6  
char Enable_Internal_seven_Segment = 0;
//////////////////////////////////////////
#include <I2A_SevSeg_V1_.h>
#include <I2A_TimerOne_.h>

SevSeg sevseg; //Instantiate a seven segment controller object
//////////////////////////////////////////
void refresh_Segment(void)
{
	sevseg.refreshDisplay();
}
void seven_segment_init_V2(char e){
  if((e==3)|(e==5))
  {
   Enable_Internal_seven_Segment=1;	  
   byte numDigits = 4;   
   //byte digitPins[] = {SEG_SEL1, SEG_SEL2, SEG_SEL3, SEG_SEL4}; //Digits: 1,2,3,4 <--put one resistor (ex: 220 Ohms, or 330 Ohms, etc, on each digit pin)
   byte digitPins[] = {SEG_SEL4, SEG_SEL3, SEG_SEL2, SEG_SEL1}; //Digits: 1,2,3,4 <--put one resistor (ex: 220 Ohms, or 330 Ohms, etc, on each digit pin)
   byte segmentPins[] = {SEG_A,SEG_B,SEG_C,SEG_D,SEG_E,SEG_F,SEG_G,SEG_P};//Segments: A,B,C,D,E,F,G,Period
   sevseg.begin(COMMON_CATHODE, numDigits, digitPins, segmentPins);
   sevseg.setBrightness(100); 
    Timer1.initialize(500);
    Timer1.attachInterrupt(refresh_Segment); // blinkLED to run every 0.15 seconds
  }
  else 
  {
	 Wire.begin(); 
  }
}
//////////////////////////////////////////
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void write_to_sevensegment_V2_(char *str,char add)
{
  int32_t Data ;
  int8_t len,i;
  char send_buff[4];
  len=strlen(str);
  if(len==0) {str[0]=' ';str[1]=' ';str[2]=' ';str[3]=' ';}
  if(len==1) {str[1]=' ';str[2]=' ';str[3]=' ';}
  if(len==2) {str[2]=' ';str[3]=' ';}
  if(len==3) {str[3]=' ';}
  Data=str[0];
  Data=Data<<8;
  Data|=str[1];
  Data=Data<<8;   
  Data|=str[2];
  Data=Data<<8;   
  Data|=str[3];
  Data+=6777215;
  send_buff[0]=Data>>24;
  send_buff[1]=Data>>16;
  send_buff[2]=Data>>8;
  send_buff[3]=Data;
   if(add==0){
   Wire.beginTransmission(15);
   Wire.write(send_buff,4);
   Wire.endTransmission();
  }
   else if(add==1){
   Wire.beginTransmission(60);
   Wire.write(send_buff,4);
   Wire.endTransmission();
  }
   else if(add==2){
   Wire.beginTransmission(61);
   Wire.write(send_buff,4);
   Wire.endTransmission();
  }
  else if(add==4){
   Wire.beginTransmission(98);
   Wire.write(send_buff,4);
   Wire.endTransmission();
  }
  else if((add==3)|(add==5)){
	  sevseg.setChars(str); 
  }
  delay(10);
}
//////////////////////////////////////////

//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void write_to_sevensegment_Text_V2(char *str,char add)
{
  int8_t len,i;
  char send_buff[5];
  len=strlen(str);
  if(len==0) {send_buff[0]=' ';send_buff[1]=' ';send_buff[2]=' ';send_buff[3]=' ';}
  else if(len==1) {send_buff[0]=str[0];send_buff[1]=' ';send_buff[2]=' ';send_buff[3]=' ';}
  else if(len==2) {send_buff[0]=str[0];send_buff[1]=str[1];send_buff[2]=' ';send_buff[3]=' ';}
  else if(len==3) {send_buff[0]=str[0];send_buff[1]=str[1];send_buff[2]=str[2];send_buff[3]=' ';}
  else {send_buff[0]=str[0];send_buff[1]=str[1];send_buff[2]=str[2];send_buff[3]=str[3];send_buff[4]=str[4];}
   if(add==0){
   Wire.beginTransmission(15);
   Wire.write(send_buff,4);
   Wire.endTransmission();
  }
   else if(add==1){
   Wire.beginTransmission(60);
   Wire.write(send_buff,4);
   Wire.endTransmission();
  }
   else if(add==2){
   Wire.beginTransmission(61);
   Wire.write(send_buff,4);
   Wire.endTransmission();
  }
  else if(add==4){
   Wire.beginTransmission(98);
   Wire.write(send_buff,4);
   Wire.endTransmission();
  }
  else if((add==3)|(add==5)){
	  sevseg.setChars(send_buff); 
  }
  delay(10);
}
//////////////////////////////////////////
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void write_to_sevensegment_V2(float F_number,char add)
{
  int8_t f_point;
  int32_t segs_value,fb;
  int16_t point;
  int16_t integer;
  char  seg_value_buffer[4];
  
  if(F_number<0)
  {
	  if((F_number<-1)&(F_number>-10)){fb=F_number*100;F_number=fb;F_number=F_number/100;}
	  if((F_number<-10)&(F_number>-100)){fb=F_number*10;F_number=fb;F_number=F_number/10;}
	  if((F_number<-100)){fb=F_number;F_number=fb;F_number=F_number;}
  }
  segs_value=F_number*1000;
  if(F_number<0){seg_value_buffer[3] = 1; segs_value *= -1;}else {seg_value_buffer[3] = 0;}
  if (segs_value > 9999999) segs_value = 10000000;
  if (segs_value < -999999) segs_value = -1000000;
  

  //if(F_number < 0) {seg_value_buffer[3] = 1; segs_value *= -1;}
  seg_value_buffer[0] = (segs_value) & 0xff;
  seg_value_buffer[1] = (segs_value >> 8) & 0xff;
  seg_value_buffer[2] = (segs_value >> 16) & 0xff;  
  if(add==0){
   Wire.beginTransmission(15);
   Wire.write(seg_value_buffer,4);
   Wire.endTransmission();
  }
   if(add==1){
   Wire.beginTransmission(60);
   Wire.write(seg_value_buffer,4);
   Wire.endTransmission();
  }
   if(add==2){
   Wire.beginTransmission(61);
   Wire.write(seg_value_buffer,4);
   Wire.endTransmission();
  }
  if(add==4){
   Wire.beginTransmission(98);
   Wire.write(seg_value_buffer,4);
   Wire.endTransmission();
  }
  else if((add==3)|(add==5)){
  if((segs_value>9999000)|(segs_value<-9999000))
  {
      sevseg.setChars("----");
  }
  else 
  {
     point=segs_value%1000;
     if       ((segs_value%10  )>0)point=3;
     else if  ((segs_value%100 )>0)point=2;
     else if  ((segs_value%1000)>0)point=1;
     else                          point=0; 
     integer=segs_value/1000;
     if      (integer>=1000){f_point=0;}
     else  if(integer>= 100){f_point=1;}
     else  if(integer>=  10){f_point=2;}
     else  if(integer>=   0){f_point=3;}
     if(f_point>point)f_point=point;
     if(f_point==0)segs_value=segs_value/1000;
     if(f_point==1)segs_value=segs_value/100;
     if(f_point==2)segs_value=segs_value/10;
     if(f_point==3)segs_value=segs_value/1; 
     if(F_number<0)segs_value*=-1;
     sevseg.setNumber(segs_value,f_point);
  }
  }  
  delay(10);
}
//////////////////////////////////////////

//////////////////////////////////////////
//////////////////////////////////////////
//////////////////////////////////////////
//////////////////////////////////////////
//////////////////////////////////////////
//////////////////////////////////////////

#endif