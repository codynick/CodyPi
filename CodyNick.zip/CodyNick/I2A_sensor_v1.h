#ifndef I2A_sensro_v1_0
#define I2A_sensro_v1_0
#define ADC_PORT_Soild_Moisture      16  //PA2
#define ADC_PORT_Ligth_Sensor        17  //PA3
#include <avr/wdt.h>
const uint16_t soil_hum_i2c_add[3]={27,60,0};
uint64_t soil_humidity_timer=0;
uint32_t soil_humidity[3];
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void init_soild_moisture_(char e)
{
 if(e!=2)return;
 pinMode(ADC_PORT_Soild_Moisture , INPUT);
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void init_Ligth_Sensor_(char e)
{
 pinMode(ADC_PORT_Ligth_Sensor , INPUT);
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
float get_Ligth_Sensor_value(uint8_t add)
{
  float f_ret;
  uint16_t ADC_value=1023,temp;
 
  if((add==0)){
	ADC_value=analogRead(ADC_PORT_Ligth_Sensor);  
	ADC_value=1023-ADC_value; 
     f_ret=	ADC_value;
	 f_ret=f_ret*100;
	 f_ret=f_ret/1023;
	  delay(100);
	 return f_ret;
  }
  if((add==1)){
   if (millis() - soil_humidity_timer > 100) {
   wdt_enable(WDTO_2S);
   soil_humidity_timer= millis();
   Wire.requestFrom(103, 2);
   if (Wire.available()) {
   uint8_t i2cdata[3];
   Wire.readBytes(i2cdata,2);
    ADC_value=i2cdata[0];
	ADC_value=ADC_value<<8;
	ADC_value+=i2cdata[1];
   }wdt_disable();}	  
ADC_value=1023-ADC_value; 
     f_ret=	ADC_value;
	 f_ret=f_ret*100;
	 f_ret=f_ret/1023;
	 delay(100);
	 return f_ret;
  }  	
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void get_soild_moisture_value(uint8_t add)
{
   uint16_t ADC_value=0,temp;
   
  if((add==0)|(add==1))
  {
   if (millis() - soil_humidity_timer> 2000) {
   wdt_enable(WDTO_2S);
   soil_humidity_timer = millis();
   Wire.requestFrom(soil_hum_i2c_add[add], 1);
   while (Wire.available()) {
   uint8_t i2cdata[1];
   Wire.readBytes(i2cdata,1);
   soil_humidity[add] = (i2cdata[0]);
   }wdt_disable();}	
  }
  else if((add==2)|(add==3))
  {
   ADC_value=analogRead(ADC_PORT_Soild_Moisture);
   temp=ADC_value/20;
   temp= (1024 - ADC_value)/8;
   if(temp>100)temp=100;   
   soil_humidity[add]=temp;
   delay(100);
  }	
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
uint16_t get_heart_rate_value(uint8_t add)
{
   uint16_t ADC_value=0,temp;
   uint64_t get_heart_rate_timer;
  
   if (millis() - get_heart_rate_timer> 2000) {
   wdt_enable(WDTO_2S);
   get_heart_rate_timer = millis();
   Wire.requestFrom(99, 2);
   while (Wire.available()) {
   uint8_t i2cdata[2];
   Wire.readBytes(i2cdata,2);
   ADC_value = i2cdata[0];
   ADC_value=ADC_value<<8;
   ADC_value+=i2cdata[1];
   }wdt_disable();}	
  return ADC_value;

}
#endif

