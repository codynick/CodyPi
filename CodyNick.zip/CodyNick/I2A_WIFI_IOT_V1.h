#ifndef I2A_WIFI_IOT_______V1
#define I2A_WIFI_IOT_______V1
#include <Arduino.h>
#include <Wire.h>
#include <SoftwareSerial.h>
#include <Wire.h>
#include <avr/wdt.h>
int X_POS=0,Y_POS=0;
char COLOR_CODE[10];
char IOT_STRING______[20];
////////////////////////////////////////////////////////////////
void Set_Wifi_IOT_Button_Text(char *str_button,int button_number){
 char i2cdata[30],i;
  if(button_number>5)button_number=5;
  if(button_number<0)button_number=0;
  i2cdata[0]=0x12;
  i2cdata[1]=button_number;
  strcpy(i2cdata+2, str_button);
  
  Wire.beginTransmission(110);
  Wire.write(i2cdata,20);
  Wire.endTransmission();
}
////////////////////////////////////////////////////////////////
void Set_Wifi_IOT_Button_Number(int button_number){
  char i2cdata[30],i;
  if(button_number>5)button_number=5;
  if(button_number<0)button_number=0;
  i2cdata[0]=0x11;
  i2cdata[1]=button_number; 
  Wire.beginTransmission(110);
  Wire.write(i2cdata,20);
  Wire.endTransmission();
}
////////////////////////////////////////////////////////////////
int Get_State_Wifi_IOT_Button_Number(int button_number){
  char i2cdata[30],i,counter;
  uint64_t www_iot_timer;
  i2cdata[0]=0x13;
  i2cdata[1]=button_number;
  delay(20);
  Wire.beginTransmission(110);
  Wire.write(i2cdata,20);
  delay(10);
  Wire.endTransmission();
	
  delay(20);
    if (millis() - www_iot_timer > 2000) {
  wdt_enable(WDTO_2S);
  www_iot_timer = millis();
  Wire.requestFrom(110, 25);
  i=0;
  delay(10);
  counter=0;
  while (Wire.available()) {
	delay(10);
   //Wire.readBytes(i2cdata,25);
   //i=i2cdata[button_number];
   i2cdata[counter]=Wire.read();
   counter++;

  }wdt_disable();}
  i=i2cdata[button_number];

 return i;
}
////////////////////////////////////////////////////////////////
void Set_Wifi_IOT_Lable_Number(int button_number){
  char i2cdata[30],i;
  if(button_number>5)button_number=5;
  if(button_number<0)button_number=0;
  i2cdata[0]=0x21;
  i2cdata[1]=button_number;
  Wire.beginTransmission(110);
  Wire.write(i2cdata,20);
  Wire.endTransmission();
}
////////////////////////////////////////////////////////////////
void Set_Wifi_IOT_Lable_Text(char *str_button,int button_number){
 char i2cdata[30],i;
  if(button_number>5)button_number=5;
  if(button_number<0)button_number=0;
  i2cdata[0]=0x22;
  i2cdata[1]=button_number;
  strcpy(i2cdata+2, str_button);
  Wire.beginTransmission(110);
  Wire.write(i2cdata,20);
  Wire.endTransmission();
}
////////////////////////////////////////////////////////////////
void Set_Wifi_IOT_Lable_VALUE(int button_number,float value_to_set){
  char i2cdata[30],i;
  long L;
  float f;
    union {
    float F;
	long L;
    unsigned char bytes[4];
  } thing;
  i2cdata[0]=0x23;
  i2cdata[1]=button_number;
  if(button_number>5)button_number=5;
  if(button_number<0)button_number=0;	
  thing.L=value_to_set*1000;
  //L=thing.L;
  
  
  
  i2cdata[2] = thing.bytes[0];
  i2cdata[3] = thing.bytes[1];
  i2cdata[4] = thing.bytes[2];
  i2cdata[5] = thing.bytes[3];
  


  
   delay(10);
  Wire.beginTransmission(110);
  Wire.write(i2cdata,20);
  Wire.endTransmission();

 delay(50);
}
////////////////////////////////////////////////////////////////
void Set_Wifi_IOT_TextBox_Number(int button_number){
  char i2cdata[30],i;
  if(button_number>5)button_number=5;
  if(button_number<0)button_number=0;
  i2cdata[0]=0x31;
  i2cdata[1]=button_number;
  Wire.beginTransmission(110);
  Wire.write(i2cdata,20);
  Wire.endTransmission();
}
////////////////////////////////////////////////////////////////
void Set_Wifi_IOT_TextBox_Text(char *str_button,int button_number){
 char i2cdata[30],i;
  if(button_number>5)button_number=5;
  if(button_number<0)button_number=0;
  i2cdata[0]=0x32;
  i2cdata[1]=button_number;
  strcpy(i2cdata+2, str_button);
  Wire.beginTransmission(110);
  Wire.write(i2cdata,20);
  Wire.endTransmission();
}
////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////
char * Get_State_Wifi_IOT_TextBox(int button_number){
  char str_value[50];
  char i2cdata[30],i;
  uint64_t www_iot_timer;
  IOT_STRING______[0]=0;IOT_STRING______[1]=0;IOT_STRING______[3]=0;
  if(button_number<1)button_number=1;
  button_number-=1;
  
  i2cdata[0]=0x33;
  i2cdata[1]=button_number;
  Wire.beginTransmission(110);
  Wire.write(i2cdata,20);
  Wire.endTransmission();
	
  delay(20);
    if (millis() - www_iot_timer > 2000) {
  wdt_enable(WDTO_2S);
  www_iot_timer = millis();
  Wire.requestFrom(110, 25);
  i=0;
  delay(10);
  while (Wire.available()) {
  
   Wire.readBytes(i2cdata,25);
   i=i2cdata[button_number];
   
  // Serial.print(button_number);
  // Serial.print(i2cdata[button_number]);

  }wdt_disable();}
  
  //sprintf(i2cdata,"TESAFFGDFS");
  
  //Serial.println(i2cdata+2);
  strcpy(IOT_STRING______,i2cdata+2);
  
 delay(20);
 return IOT_STRING______;

}
////////////////////////////////////////////////////////////////
void Set_Wifi_IOT_Color_Keepper_Number(int button_number){
  char i2cdata[30],i;
  if(button_number>5)button_number=5;
  if(button_number<0)button_number=0;
  i2cdata[0]=0x41;
  i2cdata[1]=button_number;
  Wire.beginTransmission(110);
  Wire.write(i2cdata,20);
  Wire.endTransmission();
}
////////////////////////////////////////////////////////////////
void Set_Wifi_IOT_Color_Keepper_Text(char *str_button,int button_number){
 char i2cdata[30],i;
  if(button_number>5)button_number=5;
  if(button_number<0)button_number=0;
  i2cdata[0]=0x42;
  i2cdata[1]=button_number;
  strcpy(i2cdata+2, str_button);
  Wire.beginTransmission(110);
  Wire.write(i2cdata,20);
  Wire.endTransmission();
}
////////////////////////////////////////////////////////////////
uint32_t  Get_State_Wifi_IOT_Keepper(int button_number){
  char str_value[50];
  char i2cdata[30],i,counter;;
  uint64_t www_iot_timer;
  uint32_t Coler_code;
    union {
    float F;
	long L;
	uint32_t ul;
    unsigned char bytes[4];
  } thing;
  
  if(button_number<1)return 0;
  button_number-=1;
  
  i2cdata[0]=0x43;
  i2cdata[1]=button_number;
  Wire.beginTransmission(110);
  Wire.write(i2cdata,20);
  Wire.endTransmission();
	
  delay(20);
    if (millis() - www_iot_timer > 2000) {
  wdt_enable(WDTO_2S);
  www_iot_timer = millis();
  Wire.requestFrom(110, 25);
  i=0;
  //delay(100);
    counter=0;
  while (Wire.available()) {
  delay(5);
     i2cdata[counter]=Wire.read();
   counter++;
   // Wire.readBytes(i2cdata,25);
   // thing.bytes[3]=i2cdata[1];
   // thing.bytes[2]=i2cdata[2];
   // thing.bytes[1]=i2cdata[3];
   // thing.bytes[0]=i2cdata[4];

  // Serial.print(button_number);
  // Serial.print(i2cdata[button_number]);

  }wdt_disable();}

   thing.bytes[3]=i2cdata[1];
   thing.bytes[2]=i2cdata[2];
   thing.bytes[1]=i2cdata[3];
   thing.bytes[0]=i2cdata[4];

  //sprintf(i2cdata,"TESAFFGDFS");

 // Coler_code=thing.ul;

 return thing.ul;

}
////////////////////////////////////////////////////////////////
void Set_Wifi_SSID(char *str_button,int button_number){
 char i2cdata[30],i;
  if(button_number>5)button_number=5;
  if(button_number<0)button_number=0;
  i2cdata[0]=0x91;
  i2cdata[1]=button_number;
  strcpy(i2cdata+2, str_button);
  Wire.beginTransmission(110);
  Wire.write(i2cdata,20);
  Wire.endTransmission();
}
////////////////////////////////////////////////////////////////
void Set_Wifi_PASSWORD(char *str_button,int button_number){
 char i2cdata[30],i;
  if(button_number>5)button_number=5;
  if(button_number<0)button_number=0;
  i2cdata[0]=0x92;
  i2cdata[1]=button_number;
  strcpy(i2cdata+2, str_button);
  Wire.beginTransmission(110);
  Wire.write(i2cdata,20);
  Wire.endTransmission();
}
////////////////////////////////////////////////////////////////
void Set_Wifi_Mode(int button_number){
 char i2cdata[30],i;
  if(button_number>5)button_number=5;
  if(button_number<0)button_number=0;
  i2cdata[0]=0xA1;
  i2cdata[1]=button_number;
  Wire.beginTransmission(110);
  Wire.write(i2cdata,20);
  Wire.endTransmission();
}
////////////////////////////////////////////////////////////////
char * Get_IPADD(int button_number){
  char str_value[50];
  unsigned char i2cdata[30],i;
  uint64_t www_iot_timer;
  IOT_STRING______[0]=0;IOT_STRING______[1]=0;IOT_STRING______[3]=0;
  if(button_number<1)button_number=1;
  button_number-=1;
  
  i2cdata[0]=0x81;
  i2cdata[1]=button_number;
  Wire.beginTransmission(110);
  Wire.write(i2cdata,20);
  Wire.endTransmission();
	
  delay(50);
    if (millis() - www_iot_timer > 2000) {
  wdt_enable(WDTO_2S);
  www_iot_timer = millis();
  Wire.requestFrom(110, 25);
  i=0;
  delay(10);
  while (Wire.available()) {
  
   Wire.readBytes(i2cdata,25);
   i=i2cdata[button_number];
   
  // Serial.print(button_number);
  // Serial.print(i2cdata[button_number]);

  }wdt_disable();}
  
  //sprintf(i2cdata,"TESAFFGDFS");
  
  //Serial.println(i2cdata+2);
  sprintf(IOT_STRING______,"IP=%i.%i.%i.%i",i2cdata[1],i2cdata[2],i2cdata[3],i2cdata[4]);
  
 delay(50);
 return IOT_STRING______;

}
#endif