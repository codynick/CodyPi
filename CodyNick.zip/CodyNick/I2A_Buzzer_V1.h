#ifndef I2A_Buzzer_V1
#include <Arduino.h>
#define I2A_Buzzer_V1 
#define NOTE_B0  31
#define NOTE_C1  33
#define NOTE_CS1 35
#define NOTE_D1  37
#define NOTE_DS1 39
#define NOTE_E1  41
#define NOTE_F1  44
#define NOTE_FS1 46
#define NOTE_G1  49
#define NOTE_GS1 52
#define NOTE_A1  55
#define NOTE_AS1 58
#define NOTE_B1  62
#define NOTE_C2  65
#define NOTE_CS2 69
#define NOTE_D2  73
#define NOTE_DS2 78
#define NOTE_E2  82
#define NOTE_F2  87
#define NOTE_FS2 93
#define NOTE_G2  98
#define NOTE_GS2 104
#define NOTE_A2  110
#define NOTE_AS2 117
#define NOTE_B2  123
#define NOTE_C3  131
#define NOTE_CS3 139
#define NOTE_D3  147
#define NOTE_DS3 156
#define NOTE_E3  165
#define NOTE_F3  175
#define NOTE_FS3 185
#define NOTE_G3  196
#define NOTE_GS3 208
#define NOTE_A3  220
#define NOTE_AS3 233
#define NOTE_B3  247
#define NOTE_C4  262
#define NOTE_CS4 277
#define NOTE_D4  294
#define NOTE_DS4 311
#define NOTE_E4  330
#define NOTE_F4  349
#define NOTE_FS4 370
#define NOTE_G4  392
#define NOTE_GS4 415
#define NOTE_A4  440
#define NOTE_AS4 466
#define NOTE_B4  494
#define NOTE_C5  523
#define NOTE_CS5 554
#define NOTE_D5  587
#define NOTE_DS5 622
#define NOTE_E5  659
#define NOTE_F5  698
#define NOTE_FS5 740
#define NOTE_G5  784
#define NOTE_GS5 831
#define NOTE_A5  880
#define NOTE_AS5 932
#define NOTE_B5  988
#define NOTE_C6  1047
#define NOTE_CS6 1109
#define NOTE_D6  1175
#define NOTE_DS6 1245
#define NOTE_E6  1319
#define NOTE_F6  1397
#define NOTE_FS6 1480
#define NOTE_G6  1568
#define NOTE_GS6 1661
#define NOTE_A6  1760
#define NOTE_AS6 1865
#define NOTE_B6  1976
#define NOTE_C7  2093
#define NOTE_CS7 2217
#define NOTE_D7  2349
#define NOTE_DS7 2489
#define NOTE_E7  2637
#define NOTE_F7  2794
#define NOTE_FS7 2960
#define NOTE_G7  3136
#define NOTE_GS7 3322
#define NOTE_A7  3520
#define NOTE_AS7 3729
#define NOTE_B7  3951
#define NOTE_C8  4186
#define NOTE_CS8 4435
#define NOTE_D8  4699
#define NOTE_DS8 4978
int32_t Buzzer_Frequence_set_=0;
int32_t Buzzer_timer_=0;
int32_t Buzzer_timer_Counter=0;
int8_t Buzzer_STATE_FLAG_=0;

#define Buzzer_port  10
#define vibrator_port  7

#define Buzzer_port_  10
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void buzzer_initial(char e)
{
	#include <Wire.h>
#include <avr/wdt.h>
 //if(e!=1)return;
 //TCCR1A=(0<<COM1A1) | (0<<COM1A0) | (0<<COM1B1) | (0<<COM1B0) | (0<<WGM11) | (0<<WGM10);
 //TCCR1B=(0<<ICNC1) | (0<<ICES1) | (0<<WGM13) | (0<<WGM12) | (0<<CS12) | (0<<CS11) | (1<<CS10);
 //TCNT1H=0xE0;
 //TCNT1L=0xC0;
 //ICR1H=0x00;
 //ICR1L=0x00;
 //OCR1AH=0x00;
 //OCR1AL=0x00;
 //OCR1BH=0x00;
 //OCR1BL=0x00;
 	 Wire.begin();
 if((e==0)|(e==2)) pinMode(Buzzer_port_,OUTPUT);
 if((e==1)|(e==3))Wire.begin();
 //TIMSK1 |= (1 << OCIE1A);
}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void vibrator_initial(char e)
{
	#include <Wire.h>
#include <avr/wdt.h>
 //if(e!=1)return;
 //TCCR1A=(0<<COM1A1) | (0<<COM1A0) | (0<<COM1B1) | (0<<COM1B0) | (0<<WGM11) | (0<<WGM10);
 //TCCR1B=(0<<ICNC1) | (0<<ICES1) | (0<<WGM13) | (0<<WGM12) | (0<<CS12) | (0<<CS11) | (1<<CS10);
 //TCNT1H=0xE0;
 //TCNT1L=0xC0;
 //ICR1H=0x00;
 //ICR1L=0x00;
 //OCR1AH=0x00;
 //OCR1AL=0x00;
 //OCR1BH=0x00;
 //OCR1BL=0x00;

 if(e==0) pinMode(vibrator_port,OUTPUT);
 if(e==1)Wire.begin();
 //TIMSK1 |= (1 << OCIE1A);
}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void buzzer_timeout_call(void)
{
 if(Buzzer_timer_Counter>0)
  {
   Buzzer_timer_Counter--;
   Buzzer_timer_++;
   if(Buzzer_timer_>Buzzer_Frequence_set_)
   {
        Buzzer_timer_=0;
        if(Buzzer_STATE_FLAG_>=1)Buzzer_STATE_FLAG_=0;else Buzzer_STATE_FLAG_=1;
        digitalWrite(Buzzer_port_, Buzzer_STATE_FLAG_);
   } 
  }
 else 
 {Buzzer_timer_=0;digitalWrite(Buzzer_port_, 0);}
}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void set_buzzer_tone(float  Time,float Freq,uint8_t Add)
{
 //if(Buzzer_timer_Counter>0)
	 int32_t duration;
	 int32_t wt=Freq;
     duration=millis();
	 int16_t T=Time;
	 int16_t FR=Freq;
	 char i2c_data[5];

  if((Add==0)|(Add==2))
  {
	  if(Time==0)noTone(Buzzer_port_);
	  else  tone(Buzzer_port_,Freq,Time);
  }
}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void set_buzzer_tone____(int16_t  Time,int16_t Freq,uint8_t Add)
{

  char i2c_data[5];
  
  if(Add==0)
  {
  Wire.beginTransmission(46);
  i2c_data[0] = (uint8_t)Time;
  i2c_data[1] = (uint8_t)(((uint16_t)0) >> Time);

  i2c_data[2] = (uint8_t)0;
  i2c_data[3] = (uint8_t)(((uint16_t)Time) >> 8);
  Wire.write(i2c_data,4);
  Wire.endTransmission();
  }
  else if(Add==1)
  {
   Buzzer_Frequence_set_=Freq;
   Buzzer_timer_Counter=10*Time; 
  }
  
}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void set_buzzer_digital(char add,char state)
{
	if((add==0)|(add==2))
	{
		digitalWrite(Buzzer_port,state);
	}
	else if(add==1)
	{
     char tb[6];
     tb[0]=1;
     tb[1]=state;
     tb[2]=0;
     tb[3]=0;
     tb[4]=0;
   
     Wire.beginTransmission(92);
     Wire.write(tb,5);
     Wire.endTransmission();
	}
	else if(add==3)
	{
     char tb[6];
     tb[0]=state;
     tb[1]=state;
     tb[2]=0xB0;
     tb[3]=0;
     tb[4]=0;
   
     Wire.beginTransmission(101);
     Wire.write(tb,3);
     Wire.endTransmission();
	}
	else if(add==4)
	{
     char tb[6];
     tb[0]=state;
     tb[1]=state;
     tb[2]=0xB0;
     tb[3]=0xB0;
     tb[4]=0xB0;
   
     Wire.beginTransmission(102);
     Wire.write(tb,4);
     Wire.endTransmission();
	}
}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void set_Vibrator_digital(char add,char state)
{
	if(add==0)
	{
		digitalWrite(vibrator_port,state);
	}
	if(add==1)
	{
     char tb[6];
     tb[0]=3;
     tb[1]=state;
     tb[2]=0;
     tb[3]=0;
     tb[4]=0;
   
     Wire.beginTransmission(92);
     Wire.write(tb,5);
     Wire.endTransmission();
	}
}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
#endif