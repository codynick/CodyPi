#ifndef I2A_AIR_TH_V1_0
#define I2A_AIR_TH_V1_0
#include <Wire.h>
#include <avr/wdt.h>
float GET_TEMPERTURE_HUMIDITY_SENSOR_VALUE(uint8_t ADD,uint8_t Stype)
{
  uint64_t temperature_timer;
  float Rtemperature;
  int int_value;

  if (millis() - temperature_timer> 1000) {
  wdt_enable(WDTO_2S);
  temperature_timer = millis();
  Wire.requestFrom(98, 4);
  while (Wire.available()) {
  uint8_t temper[8];
   Wire.readBytes(temper,4);
   
   if(Stype==0)
   {
    int_value=temper[2];
    int_value=int_value<<8;
    int_value+=temper[3];

   }
   else if(Stype==1)
   {
	int_value=temper[0];
    int_value=int_value<<8;
    int_value+=temper[1];

   }
   	Rtemperature=int_value;
	Rtemperature=Rtemperature/10;
  }wdt_disable();}
  return Rtemperature;
}	
#endif