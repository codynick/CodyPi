float FLOW_VALUE=0;
float TOTAL_FLOW_VALUE=0;
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
float return_flow_value_V1_0(char mode)
{
	if(mode==1)return FLOW_VALUE;
	else return TOTAL_FLOW_VALUE;
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
void get_flow_value_V1_0(void)
{

	uint64_t FLOW_VALUE_TIMER=0;
   uint32_t recive;
   uint32_t recive2;
   
   if (millis() - FLOW_VALUE_TIMER > 500) {
   wdt_enable(WDTO_2S);
   FLOW_VALUE_TIMER= millis();
   Wire.requestFrom(65, 8);
   while (Wire.available()) {
   uint8_t i2cdata[8];
   Wire.readBytes(i2cdata,8);
   
   recive=i2cdata[0];
   recive=recive<<8;
   recive+=i2cdata[1];
   recive=recive<<8;
   recive+=i2cdata[2];
   recive=recive<<8;
   recive+=i2cdata[3];
   
   recive2=i2cdata[4];
   recive2=recive2<<8;
   recive2+=i2cdata[5];
   recive2=recive2<<8;
   recive2+=i2cdata[6];
   recive2=recive2<<8;
   recive2+=i2cdata[7];
     
   FLOW_VALUE=recive;
   TOTAL_FLOW_VALUE=recive2;
   FLOW_VALUE=FLOW_VALUE/1000;
   TOTAL_FLOW_VALUE=TOTAL_FLOW_VALUE/1000;
}wdt_disable();
}
}
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


