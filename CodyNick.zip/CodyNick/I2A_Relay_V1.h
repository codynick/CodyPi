void SET_RELAY(int8_t add,int8_t status)
{
   char tb[3];
   tb[0]=add;
   tb[1]=status;
   Wire.beginTransmission(80);
   Wire.write(tb,2);
   Wire.endTransmission();
}
///++++++++++++++++++++++++++++++++++++++++++
void SET_RELAY_X1_v1_0(int8_t add,int8_t status)
{
   char tb[3];
   tb[0]=add;
   tb[1]=status;
   Wire.beginTransmission(81);
   Wire.write(tb,2);
   Wire.endTransmission();
}
///++++++++++++++++++++++++++++++++++++++++++
void SET_Pump_X1_v1_0(int8_t add,int8_t status)
{
   char tb[3];
   tb[0]=add;
   tb[1]=status;
   Wire.beginTransmission(90);
   Wire.write(tb,2);
   Wire.endTransmission();
}
///++++++++++++++++++++++++++++++++++++++++++