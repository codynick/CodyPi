
////////////////////////////////////////////////////////////////
float get_sound_sensor_value(char e)
{
	float f;
	uint64_t Sound_sensor_timer;
	int digital_aound_sensor_ = 0;
    int sound_level_ = 0;
   
  if (millis() - Sound_sensor_timer > 2000) {
  wdt_enable(WDTO_2S);
  Sound_sensor_timer = millis();
  Wire.requestFrom(96, 3);
  while (Wire.available()) {
  uint8_t i2cdata[3];
  Wire.readBytes(i2cdata,3);
  digital_aound_sensor_ = i2cdata[0];
  sound_level_=i2cdata[2];
  sound_level_=sound_level_<<8;
  sound_level_+=i2cdata[1];
  //sound_level_=850;
  }wdt_disable();}
	if(e==0)f= sound_level_;
	if(e==1)f= digital_aound_sensor_;
	
	return f;
}	
////////////////////////////////////////////////////////////////